"""Что входит в самый дешёвый тариф авиакомпании (baggage.json) — строка для поста."""
import json
import logging
from pathlib import Path

log = logging.getLogger(__name__)
FILE = Path(__file__).with_name("baggage.json")

_default = ""
_airlines: dict[str, str] = {}


def load():
    global _default, _airlines
    try:
        data = json.loads(FILE.read_text(encoding="utf-8"))
        _default = data.get("default", "")
        _airlines = {k.upper(): v for k, v in (data.get("airlines") or {}).items()}
    except Exception as e:
        log.warning("baggage.json not loaded: %s", e)


def line(airline: str | None) -> str | None:
    return _airlines.get((airline or "").upper()) or _default or None
