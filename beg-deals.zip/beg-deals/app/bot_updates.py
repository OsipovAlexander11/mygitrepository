"""
Приём обновлений от Telegram (long polling): кнопки под черновиками новостей и команда /id.

- «✅ Опубликовать» / «❌ Пропустить» под черновиком — только для ADMIN_IDS;
- ответ админа на черновик своим текстом — заменяет текст черновика (затем жмёшь «Опубликовать»);
- /id в личке боту — бот отвечает твоим Telegram ID (нужен для ADMIN_IDS).
"""
import asyncio
import html
import logging

import httpx

from . import config, db

log = logging.getLogger(__name__)

def _api(method: str) -> str:
    return f"https://api.telegram.org/bot{config.TG_TOKEN}/{method}"


async def _call(c: httpx.AsyncClient, method: str, **payload) -> dict:
    r = await c.post(_api(method), json=payload)
    return r.json()


def _kb(news_id: str) -> dict:
    return {"inline_keyboard": [[{"text": "✅ Опубликовать", "callback_data": f"news:pub:{news_id}"},
                                 {"text": "❌ Пропустить", "callback_data": f"news:skip:{news_id}"}]]}


async def _on_callback(c: httpx.AsyncClient, q: dict):
    user = q["from"]["id"]
    data = q.get("data", "")
    if user not in config.ADMIN_IDS:
        await _call(c, "answerCallbackQuery", callback_query_id=q["id"], text="Только для админа канала")
        return
    if not data.startswith("news:"):
        return
    _, action, news_id = data.split(":", 2)
    async with db.pool.connection() as conn:
        row = await (await conn.execute("SELECT body, status FROM news WHERE id = %s", (news_id,))).fetchone()
    if not row:
        await _call(c, "answerCallbackQuery", callback_query_id=q["id"], text="Черновик не найден")
        return
    body, status = row
    msg = q["message"]
    if status != "draft":
        await _call(c, "answerCallbackQuery", callback_query_id=q["id"], text=f"Уже обработан: {status}")
        return
    if action == "pub":
        res = await _call(c, "sendMessage", chat_id=config.TG_CHANNEL, text=body, parse_mode="HTML",
                          link_preview_options={"is_disabled": True})
        if not res.get("ok"):
            await _call(c, "answerCallbackQuery", callback_query_id=q["id"], text="Ошибка публикации, см. логи")
            log.warning("news publish failed: %s", res)
            return
        new_status, mark = "posted", "✅ Опубликовано"
    else:
        new_status, mark = "skipped", "❌ Пропущено"
    async with db.pool.connection() as conn:
        await conn.execute("UPDATE news SET status = %s WHERE id = %s", (new_status, news_id))
    await _call(c, "editMessageText", chat_id=msg["chat"]["id"], message_id=msg["message_id"],
                text=f"{mark}\n\n{body}", parse_mode="HTML", link_preview_options={"is_disabled": True})
    await _call(c, "answerCallbackQuery", callback_query_id=q["id"], text=mark)


async def _on_message(c: httpx.AsyncClient, m: dict):
    text = (m.get("text") or "").strip()
    user = (m.get("from") or {}).get("id")
    chat = m["chat"]
    if text.split("@")[0] == "/id" and chat.get("type") == "private":
        await _call(c, "sendMessage", chat_id=chat["id"],
                    text=f"Твой Telegram ID: {user}\nВпиши его в .env: ADMIN_IDS={user}")
        return
    # ответ админа на черновик — замена текста
    reply = m.get("reply_to_message")
    if not reply or user not in config.ADMIN_IDS or not text:
        return
    async with db.pool.connection() as conn:
        row = await (await conn.execute(
            "SELECT id, link, source, status FROM news WHERE draft_msg_id = %s", (reply["message_id"],))).fetchone()
        if not row or row[3] != "draft":
            return
        news_id, link, source, _ = row
        body = (f"{html.escape(text)}\n\n"
                f'Источник: <a href="{html.escape(link)}">{html.escape(source)}</a>')
        await conn.execute("UPDATE news SET body = %s WHERE id = %s", (body, news_id))
    await _call(c, "editMessageText", chat_id=chat["id"], message_id=reply["message_id"],
                text="📝 Черновик (обновлён):\n\n" + body, parse_mode="HTML",
                link_preview_options={"is_disabled": True}, reply_markup=_kb(news_id))


async def run():
    """Бесконечный long polling. Ошибки сети не роняют бота — пауза и повтор."""
    offset = None
    async with httpx.AsyncClient(timeout=70) as c:
        while True:
            try:
                params = {"timeout": 50, "allowed_updates": ["message", "callback_query"]}
                if offset:
                    params["offset"] = offset
                res = await _call(c, "getUpdates", **params)
                for u in res.get("result", []):
                    offset = u["update_id"] + 1
                    try:
                        if "callback_query" in u:
                            await _on_callback(c, u["callback_query"])
                        elif "message" in u:
                            await _on_message(c, u["message"])
                    except Exception:
                        log.exception("update handling failed")
            except Exception as e:
                log.warning("getUpdates failed: %s", e)
                await asyncio.sleep(10)
