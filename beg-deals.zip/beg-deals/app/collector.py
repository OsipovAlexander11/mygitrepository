import asyncio
import logging
from datetime import date, datetime, timedelta, timezone

from . import config, db, seasons, travelpayouts as tp

log = logging.getLogger(__name__)


def _months_ahead(n: int) -> list[str]:
    d = date.today().replace(day=1)
    out = []
    for _ in range(n):
        out.append(d.strftime("%Y-%m"))
        d = (d + timedelta(days=32)).replace(day=1)
    return out


def _parse(ts: str | None) -> datetime | None:
    return datetime.fromisoformat(ts) if ts else None


def _keep(row: dict, one_way: bool) -> bool:
    """Отсекаем то, что не стоит публиковать."""
    dep = _parse(row.get("departure_at"))
    if not dep or dep < datetime.now(timezone.utc) + timedelta(days=config.MIN_DAYS_TO_DEPARTURE):
        return False
    if row.get("transfers", 0) > config.MAX_TRANSFERS:
        return False
    if not one_way:
        ret = _parse(row.get("return_at"))
        if not ret or (row.get("return_transfers") or 0) > config.MAX_TRANSFERS:
            return False
        days = (ret.date() - dep.date()).days
        if not (config.RT_MIN_DAYS <= days <= config.RT_MAX_DAYS):
            return False
    return bool(row.get("link")) and row.get("price")


async def collect_origin(origin: str) -> int:
    rows: list[tuple] = []
    for month in _months_ahead(config.MONTHS_AHEAD):
        # общий запрос «всё из origin» + отдельные запросы по сезонным направлениям (только из главного аэропорта):
        # дальние рейсы с пересадкой в общей выдаче часто теряются
        dests: list[str | None] = [None]
        if origin == config.ORIGINS[0]:
            dests += seasons.watched_destinations(int(month[5:]))
        for dest, one_way in ((d, ow) for d in dests for ow in (True, False)):
            try:
                data = await tp.prices_for_dates(origin, month, one_way, dest)
                if dest:
                    await asyncio.sleep(0.3)  # бережём лимиты API
            except Exception as e:
                log.warning("fetch %s→%s %s ow=%s failed: %s", origin, dest or "*", month, one_way, e)
                continue
            for r in data:
                if not _keep(r, one_way):
                    continue
                rows.append((
                    origin, r["destination"], r.get("destination_airport"), one_way,
                    _parse(r["departure_at"]), _parse(r.get("return_at")) if not one_way else None,
                    r["price"], config.CURRENCY.upper(), r.get("airline"), str(r.get("flight_number") or ""),
                    r.get("transfers", 0), r.get("return_transfers"), r["link"],
                ))

    if not rows:
        # из Ниша/Кралево пустой сбор бывает — это не проблема; из Белграда — повод посмотреть
        (log.warning if origin == config.ORIGINS[0] else log.info)(
            "%s: no offers collected, keeping previous snapshot", origin)
        return 0

    async with db.pool.connection() as conn, conn.transaction():
        await conn.execute("DELETE FROM offers WHERE origin = %s", (origin,))
        async with conn.cursor() as cur:
            await cur.executemany(
                """INSERT INTO offers (origin, destination, dest_airport, one_way, depart_at, return_at,
                                       price, currency, airline, flight_number, transfers, return_transfers, link)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                rows,
            )
        # дневной минимум по маршруту — копим историю для «обычной» цены
        await conn.execute(
            """INSERT INTO price_history (origin, destination, one_way, day, min_price)
               SELECT origin, destination, one_way, current_date, min(price)
               FROM offers WHERE origin = %s
               GROUP BY origin, destination, one_way
               ON CONFLICT (origin, destination, one_way, day)
               DO UPDATE SET min_price = LEAST(price_history.min_price, EXCLUDED.min_price)""",
            (origin,),
        )
    log.info("%s: %d offers", origin, len(rows))
    return len(rows)


async def collect_all():
    total = 0
    for origin in config.ORIGINS:
        total += await collect_origin(origin)
    if total == 0:
        log.warning("collect: no offers at all — check Travelpayouts token/API")
    log.info("collect done: %d offers total", total)
