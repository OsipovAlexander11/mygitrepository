import os


def _env(name: str, default: str | None = None) -> str:
    v = os.getenv(name, default)
    if v is None:
        raise RuntimeError(f"Env {name} is required")
    return v


def _list(name: str, default: str) -> list[str]:
    return [x.strip().upper() for x in os.getenv(name, default).split(",") if x.strip()]


# --- доступы ---
TP_TOKEN = _env("TP_TOKEN", "")            # Travelpayouts API token
TP_MARKER = _env("TP_MARKER", "")          # partner marker (для комиссии)
TP_TRS = _env("TP_TRS", "")                # ID проекта в Travelpayouts (для партнёрских ссылок)
TG_TOKEN = _env("TG_TOKEN", "")            # токен бота от @BotFather
TG_CHANNEL = _env("TG_CHANNEL", "")        # @channel_name или -100xxxxxxxxxx
DATABASE_URL = _env("DATABASE_URL", "postgresql://deals:deals@db:5432/deals")

# --- что собираем ---
ORIGINS = _list("ORIGINS", "BEG,INI,KVO")  # Белград, Ниш, Кралево
CURRENCY = os.getenv("CURRENCY", "eur").lower()
MONTHS_AHEAD = int(os.getenv("MONTHS_AHEAD", "4"))
MAX_TRANSFERS = int(os.getenv("MAX_TRANSFERS", "1"))
RT_MIN_DAYS = int(os.getenv("RT_MIN_DAYS", "2"))    # туда-обратно: длина поездки
RT_MAX_DAYS = int(os.getenv("RT_MAX_DAYS", "21"))
MIN_DAYS_TO_DEPARTURE = int(os.getenv("MIN_DAYS_TO_DEPARTURE", "2"))
EXCLUDE_COUNTRIES = _list("EXCLUDE_COUNTRIES", "RS")  # внутренние рейсы (Ниш—Белград): собираем, но не постим в канал; пусто — постить всё
# коды для ссылок Aviasales, которые иначе не открываются на телефоне: EAP (Базель-Мюлуз) → MLH. Формат: EAP:MLH,XXX:YYY
LINK_CODE_OVERRIDES = dict(p.split(":", 1) for p in os.getenv("LINK_CODE_OVERRIDES", "EAP:MLH").upper().replace(" ", "").split(",") if ":" in p)
AVIASALES_HOST = os.getenv("AVIASALES_HOST", "https://www.aviasales.com")

# --- что считаем выгодным ---
DISCOUNT = float(os.getenv("DISCOUNT", "0.20"))          # дешевле медианы за 30 дней на 20%+
MIN_OBSERVATIONS = int(os.getenv("MIN_OBSERVATIONS", "5"))  # дней истории для медианы
ABS_ONEWAY = float(os.getenv("ABS_ONEWAY", "35"))        # или просто дешевле X € в одну сторону
ABS_ROUNDTRIP = float(os.getenv("ABS_ROUNDTRIP", "70"))  # или дешевле Y € туда-обратно
# для безвизовых направлений (по VISA_MAIN) пороги выше: Турция, Египет, ОАЭ дальше и дороже Wizz по Европе
ABS_ONEWAY_VISAFREE = float(os.getenv("ABS_ONEWAY_VISAFREE", "60"))
ABS_ROUNDTRIP_VISAFREE = float(os.getenv("ABS_ROUNDTRIP_VISAFREE", "120"))
# пока нет истории: сравниваем с медианой цен этого маршрута по другим датам в текущем срезе
SNAP_MIN_DATES = int(os.getenv("SNAP_MIN_DATES", "5"))
DEST_REPOST_DAYS = int(os.getenv("DEST_REPOST_DAYS", "3"))  # тот же город из другого аэропорта — не раньше чем через N дней
MAX_GROUP_PER_DAY = int(os.getenv("MAX_GROUP_PER_DAY", "2"))  # постов одной группы (зимнее солнце…) в день
REPOST_DAYS = int(os.getenv("REPOST_DAYS", "7"))         # не повторять маршрут N дней (если не подешевел на 10%+)

# --- визы ---
VISA_PASSPORTS = _list("VISA_PASSPORTS", "RU,BY,UA")  # для каких паспортов показывать визовый режим
# none — только показывать; any — публиковать, если без визы хотя бы для одного паспорта;
# all — без визы для всех; ru / by / ua — без визы для конкретного паспорта
VISA_FILTER = os.getenv("VISA_FILTER", "none").lower()
VISA_MAIN = os.getenv("VISA_MAIN", "RU").upper()  # основной паспорт аудитории: по нему решаем «безвиз или нет»
VISA_EASY_BONUS = float(os.getenv("VISA_EASY_BONUS", "0.15"))  # приоритет безвизовым направлениям
MAX_VISA_POSTS_PER_DAY = int(os.getenv("MAX_VISA_POSTS_PER_DAY", "1"))  # сколько постов в день туда, где VISA_MAIN нужна виза
DATA_DIR = os.getenv("DATA_DIR", "/srv/data")

# --- рекламная пометка (из Travelpayouts → Create link), добавляется в каждый пост ---
AD_DISCLOSURE = os.getenv("AD_DISCLOSURE", "").strip()

# --- SerpApi (Google Flights): проверка цены перед постом и подборка «выходные» ---
SERPAPI_KEY = os.getenv("SERPAPI_KEY", "").strip()          # пусто — проверка выключена
SERPAPI_RESERVE = int(os.getenv("SERPAPI_RESERVE", "10"))   # сколько запросов в месяце не тратить на проверки (под «выходные»)
VERIFY_TOLERANCE = float(os.getenv("VERIFY_TOLERANCE", "0.15"))  # Google дороже нашей цены больше чем на 15% — не постим
VERIFY_SKIP_HIGH = os.getenv("VERIFY_SKIP_HIGH", "true").lower() == "true"  # Google считает цену высокой — не постим
# без проверки в Google (бюджет кончился / Google не нашёл рейсов) — всё равно публиковать? false — только проверенные
VERIFY_REQUIRE_GOOGLE = os.getenv("VERIFY_REQUIRE_GOOGLE", "false").lower() == "true"
RECHECK_TOLERANCE = float(os.getenv("RECHECK_TOLERANCE", "0.10"))  # свежая цена Travelpayouts выше на 10%+ — не постим
VERIFY_MAX_PER_SLOT = int(os.getenv("VERIFY_MAX_PER_SLOT", "3"))  # сколько кандидатов проверить за один слот
# подборка «Выходные: куда улететь» из Google Travel Explore: день недели (mon..sun / off) и час
WEEKEND_DAY = os.getenv("WEEKEND_DAY", "wed").lower()
WEEKEND_HOUR = int(os.getenv("WEEKEND_HOUR", "18"))
WEEKEND_MAX_PRICE = float(os.getenv("WEEKEND_MAX_PRICE", "250"))  # потолок туда-обратно для направлений с визой
WEEKEND_MAX_PRICE_VISAFREE = float(os.getenv("WEEKEND_MAX_PRICE_VISAFREE", "350"))  # и для безвизовых (они дальше)
WEEKEND_MIN_DAYS_AHEAD = int(os.getenv("WEEKEND_MIN_DAYS_AHEAD", "7"))  # ближайшие выходные, до которых ≥ N дней

# вторая цена в долларах «137 € (≈ $159)» — Aviasales часто показывает пользователям USD
SHOW_USD = os.getenv("SHOW_USD", "true").lower() == "true"

# --- новости → черновики на одобрение ---
NEWS_REVIEW_CHAT = os.getenv("NEWS_REVIEW_CHAT", "").strip()  # куда слать черновики (тестовая группа); пусто — выключено
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x}  # кто может публиковать
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()  # для заметок своими словами (и перевода EN-источников)
LLM_MODEL = os.getenv("LLM_MODEL", "claude-haiku-5-5")
NEWS_EVERY_MIN = int(os.getenv("NEWS_EVERY_MIN", "180"))
NEWS_MAX_DRAFTS = int(os.getenv("NEWS_MAX_DRAFTS", "3"))       # черновиков за один проход
NEWS_MAX_AGE_HOURS = int(os.getenv("NEWS_MAX_AGE_HOURS", "48"))

# --- расписание ---
COLLECT_EVERY_MIN = int(os.getenv("COLLECT_EVERY_MIN", "120"))
PUBLISH_EVERY_MIN = int(os.getenv("PUBLISH_EVERY_MIN", "60"))  # используется, только если POST_HOURS пуст
# часы публикации (по белградскому времени); пусто — публиковать раз в PUBLISH_EVERY_MIN минут
POST_HOURS = [int(h) for h in os.getenv("POST_HOURS", "9,11,13,15,18,20").replace(" ", "").split(",") if h]
# сколько постов в день гарантированно из региональных аэропортов (Ниш, Кралево), если там есть выгодное
REGIONAL_MIN_PER_DAY = int(os.getenv("REGIONAL_MIN_PER_DAY", "1"))
MAX_POSTS_PER_DAY = int(os.getenv("MAX_POSTS_PER_DAY", "6"))
QUIET_FROM = int(os.getenv("QUIET_FROM", "23"))  # не постить с 23:00
QUIET_TO = int(os.getenv("QUIET_TO", "8"))       # до 08:00
TZ = os.getenv("TZ_NAME", "Europe/Belgrade")
# WARNING — в логах только проблемы и ошибки; INFO — подробно (сборы, посты, проверки) для отладки
LOG_LEVEL = os.getenv("LOG_LEVEL", "WARNING").upper()
# еженедельная сезонная подборка: день недели (mon..sun) и час; DIGEST_DAY=off — выключить
DIGEST_DAY = os.getenv("DIGEST_DAY", "fri").lower()
DIGEST_HOUR = int(os.getenv("DIGEST_HOUR", "18"))
