import os


def _env(name: str, default: str | None = None) -> str:
    v = os.getenv(name, default)
    if v is None:
        raise RuntimeError(f"Env {name} is required")
    return v


def _list(name: str, default: str) -> list[str]:
    return [x.strip().upper() for x in os.getenv(name, default).split(",") if x.strip()]


# --- доступы ---
TP_TOKEN = _env("TP_TOKEN", "")            # Travelpayouts API token
TP_MARKER = _env("TP_MARKER", "")          # partner marker (для комиссии)
TP_TRS = _env("TP_TRS", "")                # ID проекта в Travelpayouts (для партнёрских ссылок)
TG_TOKEN = _env("TG_TOKEN", "")            # токен бота от @BotFather
TG_CHANNEL = _env("TG_CHANNEL", "")        # @channel_name или -100xxxxxxxxxx
DATABASE_URL = _env("DATABASE_URL", "postgresql://deals:deals@db:5432/deals")

# --- что собираем ---
ORIGINS = _list("ORIGINS", "BEG,INI,KVO")  # Белград, Ниш, Кралево
CURRENCY = os.getenv("CURRENCY", "eur").lower()
MONTHS_AHEAD = int(os.getenv("MONTHS_AHEAD", "4"))
MAX_TRANSFERS = int(os.getenv("MAX_TRANSFERS", "1"))
RT_MIN_DAYS = int(os.getenv("RT_MIN_DAYS", "2"))    # туда-обратно: длина поездки
RT_MAX_DAYS = int(os.getenv("RT_MAX_DAYS", "21"))
MIN_DAYS_TO_DEPARTURE = int(os.getenv("MIN_DAYS_TO_DEPARTURE", "2"))
EXCLUDE_COUNTRIES = _list("EXCLUDE_COUNTRIES", "RS")  # внутренние рейсы (Ниш—Белград): собираем, но не постим в канал; пусто — постить всё
AVIASALES_HOST = os.getenv("AVIASALES_HOST", "https://www.aviasales.com")

# --- что считаем выгодным ---
DISCOUNT = float(os.getenv("DISCOUNT", "0.20"))          # дешевле медианы за 30 дней на 20%+
MIN_OBSERVATIONS = int(os.getenv("MIN_OBSERVATIONS", "5"))  # дней истории для медианы
ABS_ONEWAY = float(os.getenv("ABS_ONEWAY", "35"))        # или просто дешевле X € в одну сторону
ABS_ROUNDTRIP = float(os.getenv("ABS_ROUNDTRIP", "70"))  # или дешевле Y € туда-обратно
# для безвизовых направлений (по VISA_MAIN) пороги выше: Турция, Египет, ОАЭ дальше и дороже Wizz по Европе
ABS_ONEWAY_VISAFREE = float(os.getenv("ABS_ONEWAY_VISAFREE", "60"))
ABS_ROUNDTRIP_VISAFREE = float(os.getenv("ABS_ROUNDTRIP_VISAFREE", "120"))
# пока нет истории: сравниваем с медианой цен этого маршрута по другим датам в текущем срезе
SNAP_MIN_DATES = int(os.getenv("SNAP_MIN_DATES", "5"))
REPOST_DAYS = int(os.getenv("REPOST_DAYS", "7"))         # не повторять маршрут N дней (если не подешевел на 10%+)

# --- визы ---
VISA_PASSPORTS = _list("VISA_PASSPORTS", "RU,BY,UA")  # для каких паспортов показывать визовый режим
# none — только показывать; any — публиковать, если без визы хотя бы для одного паспорта;
# all — без визы для всех; ru / by / ua — без визы для конкретного паспорта
VISA_FILTER = os.getenv("VISA_FILTER", "none").lower()
VISA_MAIN = os.getenv("VISA_MAIN", "RU").upper()  # основной паспорт аудитории: по нему решаем «безвиз или нет»
VISA_EASY_BONUS = float(os.getenv("VISA_EASY_BONUS", "0.15"))  # приоритет безвизовым направлениям
MAX_VISA_POSTS_PER_DAY = int(os.getenv("MAX_VISA_POSTS_PER_DAY", "1"))  # сколько постов в день туда, где VISA_MAIN нужна виза
DATA_DIR = os.getenv("DATA_DIR", "/srv/data")

# --- рекламная пометка (из Travelpayouts → Create link), добавляется в каждый пост ---
AD_DISCLOSURE = os.getenv("AD_DISCLOSURE", "").strip()

# --- расписание ---
COLLECT_EVERY_MIN = int(os.getenv("COLLECT_EVERY_MIN", "120"))
PUBLISH_EVERY_MIN = int(os.getenv("PUBLISH_EVERY_MIN", "60"))
# сколько постов в день гарантированно из региональных аэропортов (Ниш, Кралево), если там есть выгодное
REGIONAL_MIN_PER_DAY = int(os.getenv("REGIONAL_MIN_PER_DAY", "1"))
MAX_POSTS_PER_DAY = int(os.getenv("MAX_POSTS_PER_DAY", "6"))
QUIET_FROM = int(os.getenv("QUIET_FROM", "23"))  # не постить с 23:00
QUIET_TO = int(os.getenv("QUIET_TO", "8"))       # до 08:00
TZ = os.getenv("TZ_NAME", "Europe/Belgrade")
# еженедельная сезонная подборка: день недели (mon..sun) и час; DIGEST_DAY=off — выключить
DIGEST_DAY = os.getenv("DIGEST_DAY", "fri").lower()
DIGEST_HOUR = int(os.getenv("DIGEST_HOUR", "18"))
