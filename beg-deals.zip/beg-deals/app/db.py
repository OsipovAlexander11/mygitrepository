from psycopg_pool import AsyncConnectionPool

from . import config

SCHEMA = """
-- текущий срез цен (перезаписывается при каждом сборе по аэропорту вылета)
CREATE TABLE IF NOT EXISTS offers (
    id              bigserial PRIMARY KEY,
    origin          text NOT NULL,          -- BEG / INI / KVO
    destination     text NOT NULL,          -- IATA города назначения
    dest_airport    text,
    one_way         boolean NOT NULL,
    depart_at       timestamptz NOT NULL,
    return_at       timestamptz,
    price           numeric(10,2) NOT NULL,
    currency        text NOT NULL,
    airline         text,
    flight_number   text,
    transfers       int NOT NULL DEFAULT 0,
    return_transfers int,
    link            text NOT NULL,
    collected_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS offers_route_idx ON offers (origin, destination, one_way, price);

-- минимальная цена маршрута по дням — база для «обычной» цены
CREATE TABLE IF NOT EXISTS price_history (
    origin      text NOT NULL,
    destination text NOT NULL,
    one_way     boolean NOT NULL,
    day         date NOT NULL,
    min_price   numeric(10,2) NOT NULL,
    PRIMARY KEY (origin, destination, one_way, day)
);

-- что уже опубликовано
CREATE TABLE IF NOT EXISTS posts (
    id          bigserial PRIMARY KEY,
    origin      text NOT NULL,
    destination text NOT NULL,
    one_way     boolean NOT NULL,
    depart_at   timestamptz NOT NULL,
    return_at   timestamptz,
    price       numeric(10,2) NOT NULL,
    message_id  bigint,
    posted_at   timestamptz NOT NULL DEFAULT now()
);
-- предложения, которые не прошли проверку в Google Flights (цена ушла вверх / «высокая») — сутки их не трогаем
CREATE TABLE IF NOT EXISTS rejected (
    origin      text NOT NULL,
    destination text NOT NULL,
    one_way     boolean NOT NULL,
    depart_at   timestamptz NOT NULL,
    price       numeric(10,2) NOT NULL,
    google_price numeric(10,2),
    reason      text,
    checked_at  timestamptz NOT NULL DEFAULT now()
);
-- сколько запросов SerpApi потрачено за день (для дневного бюджета)
CREATE TABLE IF NOT EXISTS serpapi_usage (
    day   date PRIMARY KEY,
    used  int NOT NULL DEFAULT 0
);
-- новости: черновики на одобрение
CREATE TABLE IF NOT EXISTS news (
    id           text PRIMARY KEY,           -- sha1(link)
    source       text NOT NULL,
    link         text NOT NULL,
    title        text,
    body         text,
    status       text NOT NULL,              -- draft / posted / skipped / irrelevant
    draft_msg_id bigint,
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS posts_route_idx ON posts (origin, destination, one_way, posted_at DESC);
"""

pool = AsyncConnectionPool(config.DATABASE_URL, open=False, min_size=1, max_size=4)


async def init():
    await pool.open()
    async with pool.connection() as conn:
        await conn.execute(SCHEMA)
