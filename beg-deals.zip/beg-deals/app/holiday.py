"""
Подборка «В Россию и Беларусь на Новый год»: билеты из Белграда в Россию и Беларусь на праздничные даты.

Цены берутся свежим запросом в Travelpayouts (а не из базы): в базе туда-обратно только в пределах одного
месяца, а праздничные поездки — декабрь → январь. По каждому городу — самый дешёвый билет «туда»
и самый дешёвый «туда-обратно» с вылетом в окне HOLIDAY_DEPART_FROM…HOLIDAY_DEPART_TO и возвратом до HOLIDAY_RETURN_TO.
"""
import asyncio
import html
import logging
from datetime import date, datetime
from zoneinfo import ZoneInfo

from . import config, rates, seasons, travelpayouts as tp

log = logging.getLogger(__name__)
TZ = ZoneInfo(config.TZ)
MON = ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"]


def _window(today: date | None = None) -> tuple[date, date, date]:
    """Ближайшие праздники: вылет с 20.12 по 06.01, возврат до 15.01 (числа — из настроек)."""
    today = today or datetime.now(TZ).date()
    y = today.year if today.month >= 7 else today.year - 1  # в январе показываем ещё текущие праздники
    md = lambda s: tuple(int(x) for x in s.split("-"))  # "12-20" → (12, 20)
    fm, fd = md(config.HOLIDAY_DEPART_FROM)
    tm, td = md(config.HOLIDAY_DEPART_TO)
    rm, rd = md(config.HOLIDAY_RETURN_TO)
    start = date(y, fm, fd)
    end = date(y + (tm < fm), tm, td)
    ret = date(y + (rm < fm), rm, rd)
    return max(start, today), end, ret


def _d(x: date) -> str:
    return f"{x.day} {MON[x.month - 1]}"


async def _query(origin: str, dest: str, dep_month: str, ret_month: str | None) -> list[dict]:
    params = {"origin": origin, "destination": dest, "departure_at": dep_month,
              "one_way": "false" if ret_month else "true", "currency": config.CURRENCY,
              "sorting": "price", "limit": 200}
    if ret_month:
        params["return_at"] = ret_month
    try:
        async with tp._client() as c:
            r = await c.get(f"{tp.API}/aviasales/v3/prices_for_dates", params=params)
            r.raise_for_status()
            return r.json().get("data") or []
    except Exception as e:
        log.info("holiday %s-%s %s/%s failed: %s", origin, dest, dep_month, ret_month, e)
        return []


def _months(a: date, b: date) -> list[str]:
    out, y, m = [], a.year, a.month
    while (y, m) <= (b.year, b.month):
        out.append(f"{y}-{m:02d}")
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


async def _back(origin: str, dest: str, start: date, ret_by: date) -> dict | None:
    """Самый дешёвый билет обратно (dest → origin) до ret_by: многие летят домой и обратно разными билетами."""
    best = None
    for m in _months(start, ret_by):
        for x in await _query(dest, origin, m, None):
            d = datetime.fromisoformat(x["departure_at"]).astimezone(TZ).date()
            if start < d <= ret_by and x.get("transfers", 0) <= config.MAX_TRANSFERS:
                if best is None or x["price"] < best["price"]:
                    best = {**x, "_dep": d}
        await asyncio.sleep(0.3)
    return best


async def _best(origin: str, dest: str, start: date, end: date, ret_by: date) -> tuple[dict | None, dict | None]:
    dep_months = _months(start, end)
    ret_months = _months(start, ret_by)
    ow, rt = None, None
    for dm in dep_months:
        for x in await _query(origin, dest, dm, None):
            dep = datetime.fromisoformat(x["departure_at"]).astimezone(TZ).date()
            if start <= dep <= end and x.get("transfers", 0) <= config.MAX_TRANSFERS:
                if ow is None or x["price"] < ow["price"]:
                    ow = {**x, "_dep": dep}
        await asyncio.sleep(0.3)
        for rm in ret_months:
            if rm < dm:
                continue
            for x in await _query(origin, dest, dm, rm):
                dep = datetime.fromisoformat(x["departure_at"]).astimezone(TZ).date()
                if not x.get("return_at"):
                    continue
                ret = datetime.fromisoformat(x["return_at"]).astimezone(TZ).date()
                days = (ret - dep).days
                if (start <= dep <= end and ret <= ret_by and 3 <= days <= 21
                        and x.get("transfers", 0) <= config.MAX_TRANSFERS
                        and (x.get("return_transfers") or 0) <= config.MAX_TRANSFERS):
                    if rt is None or x["price"] < rt["price"]:
                        rt = {**x, "_dep": dep, "_ret": ret}
            await asyncio.sleep(0.3)
    return ow, rt


def _destinations() -> list[str]:
    out = []
    for g in seasons.groups():
        if g["id"] in ("to_russia", "to_belarus"):
            out += [d for d in g["destinations"] if d not in out]
    return out or ["MOW", "LED", "MSQ"]


async def build_holiday() -> str | None:
    origin = config.ORIGINS[0]
    start, end, ret_by = _window()
    if start > end:
        return None  # праздники уже прошли
    lines = []
    for dest in _destinations():
        ow, rt = await _best(origin, dest, start, end, ret_by)
        back = await _back(origin, dest, start, ret_by)
        if ow and back and rt and float(rt["price"]) >= float(ow["price"]) + float(back["price"]):
            rt = None  # два отдельных билета дешевле — туда-обратно не показываем
        if not ow and not rt:
            continue
        flag = "🇧🇾" if tp.country_of(dest) == "BY" else "🇷🇺"
        parts = []
        if ow:
            link = await tp.partner_link(tp.search_url(origin, dest, ow["_dep"]), f"holiday-ow-{dest}")
            parts.append(f'<a href="{html.escape(link)}">туда от {rates.price(float(ow["price"]))}</a> ({_d(ow["_dep"])})')
        if back:
            link = await tp.partner_link(tp.search_url(dest, origin, back["_dep"]), f"holiday-back-{dest}")
            parts.append(f'<a href="{html.escape(link)}">обратно от {rates.price(float(back["price"]))}</a> ({_d(back["_dep"])})')
        if rt:
            link = await tp.partner_link(tp.search_url(origin, dest, rt["_dep"], rt["_ret"]), f"holiday-rt-{dest}")
            parts.append(f'<a href="{html.escape(link)}">туда-обратно от {rates.price(float(rt["price"]))}</a> '
                         f'({_d(rt["_dep"])} – {_d(rt["_ret"])})')
        # сортировка по стоимости всей поездки: туда-обратно или два билета; если обратного нет — по билету туда
        totals = [float(rt["price"])] if rt else []
        if ow and back:
            totals.append(float(ow["price"]) + float(back["price"]))
        price = min(totals) if totals else float(ow["price"]) * 2
        lines.append((price, f"{flag} <b>{html.escape(tp.city_name(dest))}</b> — " + "; ".join(parts)))
    if not lines:
        return None
    lines.sort(key=lambda x: x[0])
    text = [f"🎄 <b>В Россию и Беларусь на Новый год: билеты из {html.escape(tp.city_from(origin))}</b>",
            f"Вылет {_d(start)} – {_d(end)}, обратно до {_d(ret_by)}. Самые дешёвые варианты (туда и обратно можно брать отдельными билетами):", ""]
    text += [l for _, l in lines]
    text += ["", "На праздничные даты билеты обычно дорожают по мере приближения — лучше посмотреть заранее.",
             "<i>Цены на момент публикации, могут измениться. Даты и пересадки уточняйте при покупке.</i>"]
    if config.AD_DISCLOSURE:
        text.append(f"<i>{html.escape(config.AD_DISCLOSURE)}</i>")
    text += ["", "#новый_год #в_россию #в_беларусь"]
    return "\n".join(text)


async def publish_holiday(chat_id: str | None = None, dry_run: bool = False) -> bool:
    from .publisher import send
    text = await build_holiday()
    if not text:
        log.info("holiday: nothing to post")
        return False
    if dry_run:
        print(text)
        return True
    await send(chat_id or config.TG_CHANNEL, text)
    log.info("holiday posted")
    return True
