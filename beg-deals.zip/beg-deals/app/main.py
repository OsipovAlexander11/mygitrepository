"""
python -m app.main run          — сервис: сбор + публикация по расписанию
python -m app.main collect      — один сбор цен
python -m app.main preview [N]  — показать N лучших кандидатов (ничего не публикует)
python -m app.main test CHAT_ID — отправить лучший пост в тестовый чат (без записи в историю)
python -m app.main post         — опубликовать одно предложение в канал прямо сейчас
python -m app.main digest [CHAT] — сезонная подборка: без CHAT — только показать, с CHAT — отправить туда
python -m app.main weekend [CHAT] — «выходные» из Google Travel Explore (тратит 1 запрос SerpApi)
python -m app.main serpapi       — сколько запросов SerpApi осталось в этом месяце
"""
import asyncio
import logging
import sys

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from . import collector, config, db, publisher, seasons, serpapi, travelpayouts as tp, visa

logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.WARNING),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
# библиотечный шум (каждый HTTP-запрос, служебные сообщения планировщика) — только при проблемах
for noisy in ("httpx", "httpcore", "apscheduler"):
    logging.getLogger(noisy).setLevel(logging.WARNING)
log = logging.getLogger("beg-deals")


def _check_env(*names: str):
    missing = [n for n in names if not getattr(config, n)]
    if missing:
        sys.exit(f"Не заданы переменные окружения: {', '.join(missing)}")


async def _safe(coro_fn, *a, **kw):
    try:
        await coro_fn(*a, **kw)
    except Exception:
        log.exception("%s failed", coro_fn.__name__)


async def run():
    _check_env("TP_TOKEN", "TG_TOKEN", "TG_CHANNEL")
    sched = AsyncIOScheduler(timezone=config.TZ)
    sched.add_job(_safe, "interval", args=[tp.load_dictionaries], hours=24)
    sched.add_job(_safe, "interval", args=[visa.load], hours=24)
    if config.DIGEST_DAY != "off":
        sched.add_job(_safe, "cron", args=[publisher.publish_digest],
                      day_of_week=config.DIGEST_DAY, hour=config.DIGEST_HOUR, minute=0)
    if serpapi.enabled() and config.WEEKEND_DAY != "off":
        sched.add_job(_safe, "cron", args=[publisher.publish_weekend],
                      day_of_week=config.WEEKEND_DAY, hour=config.WEEKEND_HOUR, minute=0)
    sched.add_job(_safe, "interval", args=[collector.collect_all], minutes=config.COLLECT_EVERY_MIN)
    if config.POST_HOURS:  # посты по расписанию: 9, 11, 13, 15, 18, 20 — когда люди листают Telegram
        sched.add_job(_safe, "cron", args=[publisher.publish_one],
                      hour=",".join(map(str, config.POST_HOURS)), minute=5)
    else:
        sched.add_job(_safe, "interval", args=[publisher.publish_one], minutes=config.PUBLISH_EVERY_MIN)
    sched.start()
    await _safe(collector.collect_all)  # первый сбор сразу при старте
    log.info("started: origins=%s, post hours=%s, serpapi=%s", ",".join(config.ORIGINS),
             ",".join(map(str, config.POST_HOURS)) or f"every {config.PUBLISH_EVERY_MIN} min",
             f"on ({await serpapi.searches_left()} left)" if serpapi.enabled() else "off")
    await asyncio.Event().wait()


async def preview(n: int):
    cands = await publisher.candidates()
    print(f"кандидатов всего: {len(cands)}; план на день с учётом лимитов:\n")
    for o in publisher.plan(cands, n):
        print(publisher.render(o, "https://example.com"), "\n" + "-" * 40)


async def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    await db.init()
    await tp.load_dictionaries()
    await visa.load()
    seasons.load()
    if cmd == "run":
        await run()
    elif cmd == "collect":
        _check_env("TP_TOKEN")
        await collector.collect_all()
    elif cmd == "preview":
        await preview(int(sys.argv[2]) if len(sys.argv) > 2 else 5)
    elif cmd == "test":
        _check_env("TG_TOKEN")
        await publisher.publish_one(chat_id=sys.argv[2], force=True)
    elif cmd == "post":
        _check_env("TG_TOKEN", "TG_CHANNEL")
        await publisher.publish_one(force=True)
    elif cmd == "digest":
        if len(sys.argv) > 2:
            _check_env("TG_TOKEN")
            await publisher.publish_digest(chat_id=sys.argv[2])
        else:
            await publisher.publish_digest(dry_run=True)
    elif cmd == "weekend":
        if len(sys.argv) > 2:
            _check_env("TG_TOKEN")
            await publisher.publish_weekend(chat_id=sys.argv[2])
        else:
            await publisher.publish_weekend(dry_run=True)
    elif cmd == "serpapi":
        print("SerpApi:", f"{await serpapi.searches_left(force=True)} запросов осталось" if serpapi.enabled()
              else "выключен (нет SERPAPI_KEY в .env)")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    asyncio.run(main())
