"""
python -m app.main run          — сервис: сбор + публикация по расписанию
python -m app.main collect      — один сбор цен
python -m app.main preview [N]  — показать N лучших кандидатов (ничего не публикует)
python -m app.main test CHAT_ID — отправить лучший пост в тестовый чат (без записи в историю)
python -m app.main post         — опубликовать одно предложение в канал прямо сейчас
python -m app.main digest [CHAT] — сезонная подборка: без CHAT — только показать, с CHAT — отправить туда
"""
import asyncio
import logging
import sys

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from . import collector, config, db, publisher, seasons, travelpayouts as tp, visa

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("beg-deals")


def _check_env(*names: str):
    missing = [n for n in names if not getattr(config, n)]
    if missing:
        sys.exit(f"Не заданы переменные окружения: {', '.join(missing)}")


async def _safe(coro_fn, *a, **kw):
    try:
        await coro_fn(*a, **kw)
    except Exception:
        log.exception("%s failed", coro_fn.__name__)


async def run():
    _check_env("TP_TOKEN", "TG_TOKEN", "TG_CHANNEL")
    sched = AsyncIOScheduler(timezone=config.TZ)
    sched.add_job(_safe, "interval", args=[tp.load_dictionaries], hours=24)
    sched.add_job(_safe, "interval", args=[visa.load], hours=24)
    if config.DIGEST_DAY != "off":
        sched.add_job(_safe, "cron", args=[publisher.publish_digest],
                      day_of_week=config.DIGEST_DAY, hour=config.DIGEST_HOUR, minute=0)
    sched.add_job(_safe, "interval", args=[collector.collect_all], minutes=config.COLLECT_EVERY_MIN)
    sched.add_job(_safe, "interval", args=[publisher.publish_one], minutes=config.PUBLISH_EVERY_MIN)
    sched.start()
    await _safe(collector.collect_all)  # первый сбор сразу при старте
    log.info("started: origins=%s", ",".join(config.ORIGINS))
    await asyncio.Event().wait()


async def preview(n: int):
    cands = await publisher.candidates()
    print(f"кандидатов всего: {len(cands)}; план на день с учётом лимитов:\n")
    for o in publisher.plan(cands, n):
        print(publisher.render(o, "https://example.com"), "\n" + "-" * 40)


async def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    await db.init()
    await tp.load_dictionaries()
    await visa.load()
    seasons.load()
    if cmd == "run":
        await run()
    elif cmd == "collect":
        _check_env("TP_TOKEN")
        await collector.collect_all()
    elif cmd == "preview":
        await preview(int(sys.argv[2]) if len(sys.argv) > 2 else 5)
    elif cmd == "test":
        _check_env("TG_TOKEN")
        await publisher.publish_one(chat_id=sys.argv[2], force=True)
    elif cmd == "post":
        _check_env("TG_TOKEN", "TG_CHANNEL")
        await publisher.publish_one(force=True)
    elif cmd == "digest":
        if len(sys.argv) > 2:
            _check_env("TG_TOKEN")
            await publisher.publish_digest(chat_id=sys.argv[2])
        else:
            await publisher.publish_digest(dry_run=True)
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    asyncio.run(main())
