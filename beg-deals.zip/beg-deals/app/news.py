"""
Новости туризма → черновики на одобрение.

Раз в NEWS_EVERY_MIN минут бот читает RSS из news.json, отбирает свежие новости по ключевым словам
(тема: визы/рейсы/аэропорты + география: Сербия и наши направления), просит LLM (Claude) решить,
важно ли это для русскоязычных в Сербии, и написать заметку на 2–3 предложения своими словами.
Черновик уходит в NEWS_REVIEW_CHAT с кнопками «Опубликовать» / «Пропустить» (их обрабатывает bot_updates.py).
Без ANTHROPIC_API_KEY — черновик из заголовка и анонса (только русскоязычные источники).
"""
import hashlib
import html
import json
import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import feedparser
import httpx

from . import config, db

log = logging.getLogger(__name__)
FILE = Path(__file__).with_name("news.json")

PROMPT = """Ты редактор Telegram-канала «Дешёвые билеты из Сербии» для русскоязычных, живущих в Сербии
(в основном с паспортами России, Беларуси и Украины). Канал публикует дешёвые билеты из Белграда, Ниша и Кралево.

Ниже новость — она может быть на сербском (латиница или кириллица), английском или русском.
Реши, полезна ли она подписчикам: новые/отменённые рейсы из Сербии, визовые правила
для паспортов РФ/РБ/Украины, правила въезда в популярные у них страны, важное про аэропорты и авиакомпании,
которыми они летают. Общие новости туриндустрии России, отели, статистика турпотока — НЕ полезны.

Если полезна — напиши заметку на русском (переведи, если новость на другом языке): короткий заголовок (до 80 символов, можно с одним эмодзи-флагом
страны в начале) и текст 2–3 предложения: что изменилось, с какой даты, кого касается. Только факты из новости,
ничего не додумывай; если дата или детали не указаны — не придумывай их. Пиши своими словами, без копирования.

Ответь ТОЛЬКО JSON без пояснений:
{"relevant": true/false, "title": "...", "text": "..."}"""

_cfg: dict = {}


def load():
    global _cfg
    try:
        _cfg = json.loads(FILE.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("news.json not loaded: %s", e)
        _cfg = {}


def enabled() -> bool:
    return bool(config.NEWS_REVIEW_CHAT and config.TG_TOKEN and _cfg.get("sources"))


def _match(text: str, words: list[str]) -> bool:
    t = text.lower()
    return any(re.search(r"(^|[^\w])" + re.escape(w.lower()), t) for w in words)


def _clean(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html.unescape(s or ""))).strip()


async def _llm(title: str, summary: str, source: str) -> dict | None:
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.post("https://api.anthropic.com/v1/messages", headers={
            "x-api-key": config.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }, json={
            "model": config.LLM_MODEL, "max_tokens": 500, "system": PROMPT,
            "messages": [{"role": "user", "content": f"Источник: {source}\nЗаголовок: {title}\n\n{summary[:3000]}"}],
        })
    if r.status_code != 200:
        log.warning("LLM error %s: %s", r.status_code, r.text[:300])
        return None
    text = "".join(b.get("text", "") for b in r.json().get("content", []))
    m = re.search(r"\{.*\}", text, re.S)
    try:
        return json.loads(m.group(0)) if m else None
    except json.JSONDecodeError:
        log.warning("LLM returned non-JSON: %s", text[:200])
        return None


def render(title: str, text: str, source: str, link: str) -> str:
    return (f"📰 <b>{html.escape(title)}</b>\n\n{html.escape(text)}\n\n"
            f'Источник: <a href="{html.escape(link)}">{html.escape(source)}</a>')


async def _send_draft(news_id: str, body: str) -> int | None:
    kb = {"inline_keyboard": [[{"text": "✅ Опубликовать", "callback_data": f"news:pub:{news_id}"},
                               {"text": "❌ Пропустить", "callback_data": f"news:skip:{news_id}"}]]}
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"https://api.telegram.org/bot{config.TG_TOKEN}/sendMessage", json={
            "chat_id": config.NEWS_REVIEW_CHAT,
            "text": "📝 Черновик новости (ответь на это сообщение своим текстом, чтобы заменить):\n\n" + body,
            "parse_mode": "HTML", "link_preview_options": {"is_disabled": True}, "reply_markup": kb,
        })
    data = r.json()
    if not data.get("ok"):
        log.warning("news draft send failed: %s", data)
        return None
    return data["result"]["message_id"]


async def fetch(max_drafts: int | None = None) -> int:
    """Собрать новости и разослать черновики. Возвращает число новых черновиков."""
    if not enabled():
        return 0
    max_drafts = max_drafts or config.NEWS_MAX_DRAFTS
    since = datetime.now(timezone.utc) - timedelta(hours=config.NEWS_MAX_AGE_HOURS)
    candidates, failed = [], 0
    async with httpx.AsyncClient(timeout=30, follow_redirects=True,
                                 headers={"User-Agent": "Mozilla/5.0 beg-deals news"}) as c:
        for src in _cfg.get("sources", []):
            if src.get("lang") != "ru" and not config.ANTHROPIC_API_KEY:
                continue  # иностранные источники без LLM не перевести
            try:
                r = await c.get(src["url"])
                r.raise_for_status()
                feed = feedparser.parse(r.content)
            except Exception as e:
                failed += 1
                log.info("news source %s failed: %s", src["name"], e)
                continue
            for e in feed.entries[:50]:
                link = e.get("link")
                if not link:
                    continue
                ts = e.get("published_parsed") or e.get("updated_parsed")
                published = datetime(*ts[:6], tzinfo=timezone.utc) if ts else datetime.now(timezone.utc)
                if published < since:
                    continue
                title, summary = _clean(e.get("title", "")), _clean(e.get("summary", ""))
                blob = f"{title} {summary}"
                if _match(blob, _cfg.get("topic", [])) and _match(blob, _cfg.get("geo", [])):
                    candidates.append((src, link, title, summary, published))
    if failed and failed == len(_cfg.get("sources", [])):
        log.warning("news: all sources failed")

    made, llm_calls = 0, 0
    for src, link, title, summary, published in sorted(candidates, key=lambda x: x[4], reverse=True):
        if made >= max_drafts or llm_calls >= config.NEWS_MAX_LLM_PER_RUN:
            break
        news_id = hashlib.sha1(link.encode()).hexdigest()[:16]
        async with db.pool.connection() as conn:
            exists = await (await conn.execute("SELECT 1 FROM news WHERE id = %s", (news_id,))).fetchone()
        if exists:
            continue
        if config.ANTHROPIC_API_KEY:
            llm_calls += 1
            res = await _llm(title, summary, src["name"])
            if res is None:
                continue  # LLM недоступен — попробуем в следующий раз
            if not res.get("relevant"):
                await _save(news_id, src, link, title, None, "irrelevant")
                continue
            body = render(res.get("title") or title, res.get("text") or "", src["name"], link)
        else:
            body = render(title, summary[:400] + ("…" if len(summary) > 400 else ""), src["name"], link)
        msg_id = await _send_draft(news_id, body)
        if msg_id:
            await _save(news_id, src, link, title, body, "draft", msg_id)
            made += 1
    if made:
        log.info("news: %d drafts sent", made)
    return made


async def _save(news_id, src, link, title, body, status, msg_id=None):
    async with db.pool.connection() as conn:
        await conn.execute(
            """INSERT INTO news (id, source, link, title, body, status, draft_msg_id)
               VALUES (%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (id) DO NOTHING""",
            (news_id, src["name"], link, title, body, status, msg_id))


async def check() -> list[str]:
    """Проверка источников: доступен ли RSS, сколько новостей и сколько проходят фильтр по словам."""
    out = []
    async with httpx.AsyncClient(timeout=30, follow_redirects=True,
                                 headers={"User-Agent": "Mozilla/5.0 beg-deals news"}) as c:
        for src in _cfg.get("sources", []):
            try:
                r = await c.get(src["url"])
                r.raise_for_status()
                feed = feedparser.parse(r.content)
                n = len(feed.entries)
                hit = sum(1 for e in feed.entries
                          if _match(f"{_clean(e.get('title', ''))} {_clean(e.get('summary', ''))}", _cfg.get("topic", []))
                          and _match(f"{_clean(e.get('title', ''))} {_clean(e.get('summary', ''))}", _cfg.get("geo", [])))
                note = "" if src.get("lang") == "ru" or config.ANTHROPIC_API_KEY else " (пропускается: нет ANTHROPIC_API_KEY для перевода)"
                out.append(f"✅ {src['name']}: {n} новостей в ленте, по ключевым словам подходят {hit}{note}")
            except Exception as e:
                out.append(f"❌ {src['name']}: {type(e).__name__} {e}")
    return out
