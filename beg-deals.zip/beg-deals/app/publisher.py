import html
import logging
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import httpx
from psycopg.rows import dict_row

from . import baggage, config, db, seasons, serpapi, travelpayouts as tp, visa

log = logging.getLogger(__name__)
TZ = ZoneInfo(config.TZ)

WEEKDAYS = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]
MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля",
          "августа", "сентября", "октября", "ноября", "декабря"]
CUR_SIGN = {"EUR": "€", "USD": "$", "RSD": "дин.", "RUB": "₽"}

# Лучшее предложение по каждому маршруту + «обычная» цена (медиана дневных минимумов за 30 дней,
# без сегодняшнего дня) + последний пост по этому маршруту.
CANDIDATES_SQL = """
WITH best AS (
    SELECT DISTINCT ON (origin, destination, one_way) *
    FROM offers
    ORDER BY origin, destination, one_way, price, transfers, depart_at
),
hist AS (
    SELECT origin, destination, one_way,
           percentile_cont(0.5) WITHIN GROUP (ORDER BY min_price) AS median,
           count(*) AS obs
    FROM price_history
    WHERE day >= current_date - 30 AND day < current_date
    GROUP BY origin, destination, one_way
),
snap AS (
    SELECT origin, destination, one_way,
           percentile_cont(0.5) WITHIN GROUP (ORDER BY price) AS snap_median,
           count(DISTINCT depart_at::date) AS snap_dates
    FROM offers
    GROUP BY origin, destination, one_way
),
last_post AS (
    SELECT DISTINCT ON (origin, destination, one_way) origin, destination, one_way, price, posted_at
    FROM posts
    ORDER BY origin, destination, one_way, posted_at DESC
)
SELECT b.*, h.median, coalesce(h.obs, 0) AS obs, s.snap_median, s.snap_dates,
       lp.price AS last_price, lp.posted_at AS last_posted_at
FROM best b
LEFT JOIN hist h USING (origin, destination, one_way)
LEFT JOIN snap s USING (origin, destination, one_way)
LEFT JOIN last_post lp USING (origin, destination, one_way)
"""


def _score(o: dict) -> float | None:
    """>0 — предложение горячее; чем больше, тем лучше. None — не публикуем."""
    price = float(o["price"])
    now = datetime.now(TZ)
    country = tp.country_of(o["destination"])
    # внутренние рейсы (Ниш — Белград) собираем и храним (пригодятся для личных алертов), но в канал не постим
    if config.EXCLUDE_COUNTRIES and (o["destination"] in config.ORIGINS or country in config.EXCLUDE_COUNTRIES):
        return None
    if not visa.passes_filter(country):
        return None

    # не повторяемся, если цена не упала ещё на 10%+
    if o["last_posted_at"] and (now - o["last_posted_at"]).days < config.REPOST_DAYS:
        if price > float(o["last_price"]) * 0.9:
            return None

    score = None
    base, _ = _base_price(o)
    if base:
        discount = 1 - price / base
        if discount >= config.DISCOUNT:
            score = discount
    easy = _visa_easy_main(country)
    group = seasons.group_for(o["destination"], o["depart_at"])
    if group:  # сезонное направление — свои пороги (Таиланд за 300 € — это хорошо, Милан — нет)
        limit = group["abs_oneway"] if o["one_way"] else group["abs_roundtrip"]
    elif o["one_way"]:
        limit = config.ABS_ONEWAY_VISAFREE if easy else config.ABS_ONEWAY
    else:
        limit = config.ABS_ROUNDTRIP_VISAFREE if easy else config.ABS_ROUNDTRIP
    if price <= limit:
        score = max(score or 0, 1 - price / limit + 0.01)
    if score is not None and easy:
        score += config.VISA_EASY_BONUS  # безвизовые для основной аудитории — в приоритете
    if score is not None and group:
        score += float(group.get("bonus", 0))
    return score


def _visa_mark(country: str | None) -> str:
    """Короткая пометка для подборки по основному паспорту; для своей страны (Россия для 🇷🇺) — без пометки."""
    req = visa.requirement(config.VISA_MAIN, country) if country else None
    if req == "-1":
        return ""
    return " · ✅ без визы" if visa.is_easy(req) else " · 🛂 нужна виза"


def _visa_easy_main(country: str | None) -> bool:
    return visa.is_easy(visa.requirement(config.VISA_MAIN, country)) if country else False


def _base_price(o: dict) -> tuple[float | None, str | None]:
    """«Обычная» цена: медиана за 30 дней истории, а пока её нет — медиана по другим датам в текущем срезе."""
    if o["median"] and o["obs"] >= config.MIN_OBSERVATIONS:
        return float(o["median"]), "hist"
    if o.get("snap_median") and (o.get("snap_dates") or 0) >= config.SNAP_MIN_DATES:
        return float(o["snap_median"]), "snap"
    return None, None


def _date(dt: datetime) -> str:
    d = dt.astimezone(TZ)
    return f"{WEEKDAYS[d.weekday()]}, {d.day} {MONTHS[d.month - 1]}"


def _transfers(n: int | None) -> str:
    if not n:
        return "прямой рейс"
    return "1 пересадка" if n == 1 else f"{n} пересадки"


def _tag(name: str) -> str:
    return "#" + "".join(ch if ch.isalnum() else "_" for ch in name)


def render(o: dict, link: str) -> str:
    src, dst = tp.city_name(o["origin"]), tp.city_name(o["destination"])
    cur = CUR_SIGN.get(o["currency"], o["currency"])
    price = f"{float(o['price']):.0f} {cur}"
    kind = "в одну сторону" if o["one_way"] else "туда-обратно"

    group = seasons.group_for(o["destination"], o["depart_at"])
    emoji = group["emoji"] if group else "🔥"
    lines = [f"{emoji} <b>{html.escape(src)} — {html.escape(dst)}</b> за <b>{price}</b> {kind}", ""]

    airline = tp.airline_name(o["airline"])
    flight = ", ".join(x for x in [airline, _transfers(o["transfers"])] if x)
    lines.append(f"✈️ {html.escape(flight)}")
    bag = baggage.line(o["airline"])
    if bag:
        lines.append(html.escape(bag))

    if o["one_way"]:
        lines.append(f"📅 {_date(o['depart_at'])}")
    else:
        days = (o["return_at"].astimezone(TZ).date() - o["depart_at"].astimezone(TZ).date()).days
        lines.append(f"📅 {_date(o['depart_at'])} → {_date(o['return_at'])} ({days} дн.)")

    visa_line, visa_free = visa.summary(tp.country_of(o["destination"]))
    if visa_line:
        lines.append(html.escape(visa_line))

    g_line = serpapi.insight_line(o.get("g"))
    if g_line:
        lines.append(html.escape(g_line))

    base, kind_ = _base_price(o)
    if not g_line and base and float(o["price"]) <= base * (1 - config.DISCOUNT):
        text = "обычно около" if kind_ == "hist" else "в другие даты около"
        lines.append(f"📉 {text} {base:.0f} {cur}")

    lines += [
        "",
        f'Билеты → <a href="{html.escape(link)}">{_date(o["depart_at"])} • {price}</a>',
        "",
        f"{_tag(src)} {_tag(dst)}" + (" #безвиз" if visa_free else "") + (f" {group['tag']}" if group else ""),
        "<i>Цена на момент публикации, может измениться. Визовые правила проверяйте перед поездкой.</i>",
    ]
    if config.AD_DISCLOSURE:
        lines.append(f"<i>{html.escape(config.AD_DISCLOSURE)}</i>")
    return "\n".join(lines)


async def send(chat_id: str, text: str, link: str | None = None) -> int:
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "link_preview_options": {"is_disabled": True},
    }
    if link:
        payload["reply_markup"] = {"inline_keyboard": [[{"text": "Смотреть билеты ✈️", "url": link}]]}
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"https://api.telegram.org/bot{config.TG_TOKEN}/sendMessage", json=payload)
        data = r.json()
        if not data.get("ok"):
            raise RuntimeError(f"Telegram: {data}")
        return data["result"]["message_id"]


async def candidates() -> list[dict]:
    async with db.pool.connection() as conn, conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(CANDIDATES_SQL)
        rows = await cur.fetchall()
    scored = [(s, o) for o in rows if (s := _score(o)) is not None]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [o for _, o in scored]


def _regional_first(cands: list[dict], regional_posted: int) -> list[dict]:
    """Если сегодня из Ниша/Кралево ещё ничего не было — лучшее региональное предложение ставим первым."""
    if regional_posted >= config.REGIONAL_MIN_PER_DAY:
        return cands
    for i, o in enumerate(cands):
        if o["origin"] != config.ORIGINS[0]:
            return [o] + cands[:i] + cands[i + 1:]
    return cands


def plan(cands: list[dict], n: int, visa_posts: int = 0, routes: set | None = None) -> list[dict]:
    """Какие посты бот выбрал бы подряд с учётом лимитов (для preview)."""
    cands = _regional_first(cands, sum(1 for r in (routes or ()) if r[0] != config.ORIGINS[0]))
    routes, out = set(routes or ()), []
    for o in cands:
        if len(out) >= n:
            break
        if (o["origin"], o["destination"]) in routes:
            continue
        if not _visa_easy_main(tp.country_of(o["destination"])):
            if visa_posts >= config.MAX_VISA_POSTS_PER_DAY:
                continue
            visa_posts += 1
        routes.add((o["origin"], o["destination"]))
        out.append(o)
    return out


async def _posted_today() -> tuple[int, set[tuple[str, str]]]:
    async with db.pool.connection() as conn:
        rows = await (await conn.execute(
            "SELECT origin, destination FROM posts WHERE posted_at >= date_trunc('day', now() AT TIME ZONE %s) AT TIME ZONE %s",
            (config.TZ, config.TZ),
        )).fetchall()
    visa_posts = sum(1 for r in rows if not _visa_easy_main(tp.country_of(r[1])))
    return len(rows), {(r[0], r[1]) for r in rows}, visa_posts


def _quiet_now() -> bool:
    h = datetime.now(TZ).hour
    if config.QUIET_FROM > config.QUIET_TO:
        return h >= config.QUIET_FROM or h < config.QUIET_TO
    return config.QUIET_FROM <= h < config.QUIET_TO


def _offer_key(o: dict) -> tuple:
    return (o["origin"], o["destination"], o["one_way"], o["depart_at"], float(o["price"]))


async def _rejected_recently() -> set[tuple]:
    async with db.pool.connection() as conn:
        rows = await (await conn.execute(
            "SELECT origin, destination, one_way, depart_at, price FROM rejected WHERE checked_at > now() - interval '24 hours'"
        )).fetchall()
    return {(r[0], r[1], r[2], r[3], float(r[4])) for r in rows}


def _reject_reason(o: dict, g: dict | None) -> str | None:
    if not g:
        return None  # проверить не удалось — публикуем как раньше
    if g.get("price") and float(g["price"]) > float(o["price"]) * (1 + config.VERIFY_TOLERANCE):
        return f"google {float(g['price']):.0f}€"
    if config.VERIFY_SKIP_HIGH and g.get("level") == "high":
        return "google: high"
    return None


async def _reject(o: dict, g: dict | None, reason: str):
    async with db.pool.connection() as conn:
        await conn.execute(
            """INSERT INTO rejected (origin, destination, one_way, depart_at, price, google_price, reason)
               VALUES (%s,%s,%s,%s,%s,%s,%s)""",
            (o["origin"], o["destination"], o["one_way"], o["depart_at"], o["price"],
             (g or {}).get("price"), reason),
        )


async def publish_one(dry_run: bool = False, chat_id: str | None = None, force: bool = False) -> bool:
    """Публикует одно лучшее предложение. dry_run — только печать, chat_id — отправить в другой чат (тест)."""
    if not force and _quiet_now():
        log.info("quiet hours, skip")
        return False
    count, today_routes, visa_posts = await _posted_today()
    if not force and count >= config.MAX_POSTS_PER_DAY:
        log.info("daily limit reached (%d)", count)
        return False

    regional_posted = sum(1 for r in today_routes if r[0] != config.ORIGINS[0])
    rejected = await _rejected_recently()
    checks = 0
    for o in _regional_first(await candidates(), regional_posted):
        if _offer_key(o) in rejected:
            continue
        # одно направление из одного города — не чаще раза в день (one-way и round-trip вместе)
        if (o["origin"], o["destination"]) in today_routes:
            continue
        # туда, где основной аудитории нужна виза (Шенген, UK) — не больше N постов в день
        if not _visa_easy_main(tp.country_of(o["destination"])):
            if visa_posts >= config.MAX_VISA_POSTS_PER_DAY:
                continue
        # проверка в Google Flights (если подключён SerpApi и не кончилась квота)
        if serpapi.enabled() and not dry_run:
            if checks >= config.VERIFY_MAX_PER_SLOT:
                log.info("verify: %d candidates rejected in a row, skip this slot", checks)
                return False
            checks += 1
            g = await serpapi.verify(o)
            reason = _reject_reason(o, g)
            if reason:
                await _reject(o, g, reason)
                log.info("verify: skip %s-%s %s€ (%s)", o["origin"], o["destination"], o["price"], reason)
                continue
            o["g"] = g
        sub_id = f"{o['origin']}-{o['destination']}-{'ow' if o['one_way'] else 'rt'}"
        link = await tp.partner_link(o["link"], sub_id)
        text = render(o, link)
        if dry_run:
            print(text, "\n" + "-" * 40)
            return True
        msg_id = await send(chat_id or config.TG_CHANNEL, text, link)
        if chat_id:  # тестовая отправка — в историю не пишем
            return True
        async with db.pool.connection() as conn:
            await conn.execute(
                """INSERT INTO posts (origin, destination, one_way, depart_at, return_at, price, message_id)
                   VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (o["origin"], o["destination"], o["one_way"], o["depart_at"], o["return_at"], o["price"], msg_id),
            )
        log.info("posted %s %s", sub_id, o["price"])
        return True

    log.info("no hot deals right now")
    return False


# ---------- еженедельная сезонная подборка ----------

DIGEST_SQL = """
SELECT * FROM offers
WHERE origin = %s AND destination = ANY(%s)
ORDER BY price, transfers, depart_at
"""


def _short_dates(o: dict) -> str:
    d = o["depart_at"].astimezone(TZ)
    if o["one_way"] or not o["return_at"]:
        return f"{d.day} {MONTHS[d.month - 1][:3]}"
    r = o["return_at"].astimezone(TZ)
    if d.month == r.month:
        return f"{d.day}–{r.day} {MONTHS[d.month - 1][:3]}"
    return f"{d.day} {MONTHS[d.month - 1][:3]} – {r.day} {MONTHS[r.month - 1][:3]}"


async def build_digest(per_group: int = 5) -> str | None:
    """Пост-подборка: лучшие цены из главного аэропорта по сезонным группам (туда-обратно в приоритете)."""
    origin = config.ORIGINS[0]
    month_now = datetime.now(TZ).month
    soon = {(month_now + i - 1) % 12 + 1 for i in range(3)}  # этот и два следующих месяца: горнолыжку анонсируем заранее
    active = [g for g in seasons.groups() if soon & set(g["months"])]
    if not active:
        return None
    blocks, used = [], set()  # город показываем только в одной группе (Тбилиси зимой — в горнолыжке, не в «городах»)
    async with db.pool.connection() as conn, conn.cursor(row_factory=dict_row) as cur:
        for g in active:
            await cur.execute(DIGEST_SQL, (origin, g["destinations"]))
            rows = await cur.fetchall()
            best: dict[str, dict] = {}
            for o in rows:  # по каждому городу: туда-обратно, если есть, иначе в одну сторону
                if o["depart_at"].astimezone(TZ).month not in g["months"] or o["destination"] in used:
                    continue  # вылет вне сезона (Тбилиси в ноябре — не горнолыжка) или город уже в другой группе
                cur_best = best.get(o["destination"])
                if cur_best is None or (cur_best["one_way"] and not o["one_way"]):
                    best[o["destination"]] = o
            picks = sorted(best.values(), key=lambda o: float(o["price"]))[:g.get("digest_limit", per_group)]
            if not picks:
                continue
            used.update(o["destination"] for o in picks)
            lines = [f"{g['emoji']} <b>{html.escape(g['title'])}</b>"]
            for o in picks:
                link = await tp.partner_link(o["link"], f"digest-{g['id']}-{o['destination']}")
                kind = "в одну сторону" if o["one_way"] else "туда-обратно"
                lines.append(
                    f'• <a href="{html.escape(link)}">{html.escape(tp.city_name(o["destination"]))}</a> — '
                    f'от {float(o["price"]):.0f} € {kind}, {_short_dates(o)}{_visa_mark(tp.country_of(o["destination"]))}'
                )
            blocks.append("\n".join(lines + [g["tag"]]))
    regional = await _regional_block()
    if regional:
        blocks.append(regional)
    if not blocks:
        return None
    src = tp.city_name(origin)
    text = [f"🗓 <b>Подборка недели: куда улететь из {html.escape(tp.city_from(origin))}</b>", ""]
    text += ["\n\n".join(blocks), "",
             f"Визы указаны для паспорта {visa.flag(config.VISA_MAIN)}. "
             "<i>Цены на момент публикации, могут измениться.</i>"]
    if config.AD_DISCLOSURE:
        text.append(f"<i>{html.escape(config.AD_DISCLOSURE)}</i>")
    return "\n".join(text)


REGIONAL_SQL = """
SELECT DISTINCT ON (origin, destination) *
FROM offers
WHERE origin = ANY(%s) AND NOT (destination = ANY(%s))
ORDER BY origin, destination, one_way, price
"""


async def _regional_block(limit: int = 5) -> str | None:
    """Блок подборки «Из Ниша и Кралево»: самые дешёвые направления из региональных аэропортов (кроме внутренних)."""
    others = config.ORIGINS[1:]
    if not others:
        return None
    async with db.pool.connection() as conn, conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(REGIONAL_SQL, (others, config.ORIGINS))
        rows = [o for o in await cur.fetchall()
                if not (config.EXCLUDE_COUNTRIES and tp.country_of(o["destination"]) in config.EXCLUDE_COUNTRIES)]
    rows = sorted(rows, key=lambda o: float(o["price"]))[:limit]
    if not rows:
        return None
    names = " и ".join(tp.city_from(c) for c in others)
    lines = [f"🛫 <b>Из {html.escape(names)}</b>"]
    for o in rows:
        link = await tp.partner_link(o["link"], f"digest-reg-{o['origin']}-{o['destination']}")
        kind = "в одну сторону" if o["one_way"] else "туда-обратно"
        lines.append(
            f'• {html.escape(tp.city_name(o["origin"]))} → <a href="{html.escape(link)}">'
            f'{html.escape(tp.city_name(o["destination"]))}</a> — от {float(o["price"]):.0f} € {kind}, '
            f'{_short_dates(o)}{_visa_mark(tp.country_of(o["destination"]))}'
        )
    return "\n".join(lines + ["#Ниш #Кралево"])


async def publish_digest(chat_id: str | None = None, dry_run: bool = False) -> bool:
    text = await build_digest()
    if not text:
        log.info("digest: nothing to post")
        return False
    if dry_run:
        print(text)
        return True
    await send(chat_id or config.TG_CHANNEL, text)
    log.info("digest posted")
    return True


# ---------- «Выходные: куда улететь» (Google Travel Explore через SerpApi) ----------

def _aviasales_path(origin: str, dest: str, start, end) -> str:
    """Ссылка на поиск Aviasales: /search/BEG1411IST161 — вылет 14.11, обратно 16.11, 1 взрослый."""
    path = f"/search/{origin}{start:%d%m}{dest}"
    if end:
        path += f"{end:%d%m}"
    return path + "1"


def _stops(n) -> str:
    return "прямой" if not n else ("1 пересадка" if n == 1 else f"{n} пересадки")


def next_weekend(today: date | None = None) -> tuple[date, date]:
    """Ближайшие выходные (пятница → воскресенье), до которых не меньше WEEKEND_MIN_DAYS_AHEAD дней:
    в среду публикуем выходные через полторы недели — успеть спланировать и купить."""
    today = today or datetime.now(TZ).date()
    fri = today + timedelta(days=(4 - today.weekday()) % 7)
    while (fri - today).days < config.WEEKEND_MIN_DAYS_AHEAD:
        fri += timedelta(days=7)
    return fri, fri + timedelta(days=2)


async def _weekend_split(origin: str, fri: date, sun: date) -> tuple[list[dict], list[dict]]:
    """Направления на выходные: (без визы для основного паспорта, с визой), каждое со своим потолком цены."""
    free, need_visa, seen = [], [], set()
    for d in sorted(await serpapi.explore(origin, fri, sun), key=lambda d: d["price"]):
        country = tp.country_of(d["airport"])
        if country in config.EXCLUDE_COUNTRIES or d["name"] in seen:
            continue
        seen.add(d["name"])
        if _visa_easy_main(country):
            if d["price"] <= config.WEEKEND_MAX_PRICE_VISAFREE:
                free.append(d)
        elif d["price"] <= config.WEEKEND_MAX_PRICE:
            need_visa.append(d)
    return free, need_visa


async def build_weekend(limit_free: int = 8, limit_visa: int = 3) -> str | None:
    origin = config.ORIGINS[0]
    fri, sun = next_weekend()
    free, need_visa = await _weekend_split(origin, fri, sun)
    if not free:  # подборка без безвизовых направлений основной аудитории не нужна — пробуем следующие выходные
        log.info("weekend %s: no visa-free destinations, trying next weekend", fri)
        fri, sun = fri + timedelta(days=7), sun + timedelta(days=7)
        free, need_visa = await _weekend_split(origin, fri, sun)
    if not free:
        log.info("weekend: no visa-free destinations for two weekends, skip")
        return None

    async def line(d):
        start, end = d["start"] or fri, d["end"] or sun
        link = await tp.partner_link(_aviasales_path(origin, d["airport"], start, end), f"weekend-{d['airport']}")
        where = html.escape(d["name"]) + (f", {html.escape(d['country'])}" if d.get("country") else "")
        return f'• <a href="{html.escape(link)}">{where}</a> — от {d["price"]:.0f} €, {_stops(d["stops"])}'

    if fri.month == sun.month:
        when = f"{fri.day}–{sun.day} {MONTHS[sun.month - 1]}"
    else:
        when = f"{fri.day} {MONTHS[fri.month - 1]} – {sun.day} {MONTHS[sun.month - 1]}"
    text = [f"🗺 <b>Выходные {when}: куда улететь из {html.escape(tp.city_from(origin))}</b>",
            "Туда в пятницу, обратно в воскресенье, цены туда-обратно.", "",
            f"✅ <b>Без визы для {visa.flag(config.VISA_MAIN)}</b>"]
    text += [await line(d) for d in free[:limit_free]]
    if need_visa:
        text += ["", "🛂 <b>Нужна виза</b>"]
        text += [await line(d) for d in need_visa[:limit_visa]]
    text += ["", "#выходные",
             "<i>Цены по данным Google Flights на момент публикации; на Aviasales могут немного отличаться.</i>"]
    if config.AD_DISCLOSURE:
        text.append(f"<i>{html.escape(config.AD_DISCLOSURE)}</i>")
    return "\n".join(text)


async def publish_weekend(chat_id: str | None = None, dry_run: bool = False) -> bool:
    if not serpapi.enabled():
        log.info("weekend: SERPAPI_KEY not set")
        return False
    text = await build_weekend()
    if not text:
        log.info("weekend: nothing to post")
        return False
    if dry_run:
        print(text)
        return True
    await send(chat_id or config.TG_CHANNEL, text)
    log.info("weekend posted")
    return True
