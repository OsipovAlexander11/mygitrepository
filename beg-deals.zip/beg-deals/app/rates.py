"""Курс EUR→USD для второй цены в постах: Aviasales часто показывает пользователям доллары,
и «137 €» в посте против «$159» на сайте выглядит как обман. Курс ЕЦБ через frankfurter (без ключа),
обновляется раз в сутки; если не получили — вторая цена просто не показывается."""
import logging

import httpx

from . import config

log = logging.getLogger(__name__)
URLS = ["https://api.frankfurter.dev/v1/latest?base=EUR&symbols=USD",
        "https://api.frankfurter.app/latest?from=EUR&to=USD"]

_usd: float | None = None


async def load():
    global _usd
    if not config.SHOW_USD:
        return
    async with httpx.AsyncClient(timeout=20) as c:
        for url in URLS:
            try:
                r = await c.get(url)
                r.raise_for_status()
                _usd = float(r.json()["rates"]["USD"])
                log.info("EUR→USD %.4f", _usd)
                return
            except Exception as e:
                last = e
    log.warning("EUR→USD rate not loaded (%s), posts without $ price", last)


def price(eur: float, cur: str = "€") -> str:
    """«137 € (≈ $159)» или просто «137 €», если курс неизвестен / выключен."""
    text = f"{eur:.0f} {cur}"
    if config.SHOW_USD and _usd and cur == "€":
        text += f" (≈ ${eur * _usd:.0f})"
    return text
