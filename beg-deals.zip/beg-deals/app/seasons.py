"""Сезонные группы направлений (seasons.json): зимнее солнце, дальние тёплые страны, горнолыжка."""
import json
import logging
from datetime import date, datetime
from pathlib import Path

log = logging.getLogger(__name__)
FILE = Path(__file__).with_name("seasons.json")

_groups: list[dict] = []


def load():
    global _groups
    try:
        _groups = json.loads(FILE.read_text(encoding="utf-8"))["groups"]
    except Exception as e:
        log.warning("seasons.json not loaded: %s", e)
        _groups = []
    log.info("season groups: %s", ", ".join(g["id"] for g in _groups) or "none")


def groups() -> list[dict]:
    return _groups


def group_for(destination: str, depart: date | datetime | None = None) -> dict | None:
    """Группа, в которую входит направление и в чей сезон попадает дата вылета."""
    month = (depart or date.today()).month
    for g in _groups:
        if destination in g["destinations"] and month in g["months"]:
            return g
    return None


def watched_destinations(month: int) -> list[str]:
    """Направления, по которым в этом месяце вылета нужно спрашивать цены отдельно."""
    out: list[str] = []
    for g in _groups:
        if month in g["months"] and g.get("watch", True):
            out += [d for d in g["destinations"] if d not in out]
    return out
