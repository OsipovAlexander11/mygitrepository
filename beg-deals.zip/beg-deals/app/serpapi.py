"""
SerpApi (Google Flights / Google Travel Explore).

- verify(o): перед постом проверяем цену в Google Flights и берём оценку Google
  («цена низкая/обычная/высокая», обычный диапазон). Если цена ушла вверх — пост пропускаем.
- explore(): «куда улететь на выходные» — направления и цены из Google Travel Explore.

Бесплатный тариф — 250 запросов в месяц, поэтому перед каждым запросом смотрим остаток
через Account API (он бесплатный) и держим резерв под подборку выходных.
Без SERPAPI_KEY модуль выключен, бот работает как раньше.
"""
import logging
import time
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import httpx

from . import config, db

log = logging.getLogger(__name__)
API = "https://serpapi.com"

_left_cache: tuple[float, int] | None = None  # (когда проверяли, сколько осталось)
_renewal: date | None = None  # когда обновится квота (из Account API)

LEVELS = {"low": "низкая", "typical": "обычная", "high": "высокая"}


def enabled() -> bool:
    return bool(config.SERPAPI_KEY)


async def searches_left(force: bool = False) -> int:
    """Остаток запросов в месяце (Account API бесплатный, кэшируем на 10 минут)."""
    global _left_cache, _renewal
    if not force and _left_cache and time.time() - _left_cache[0] < 600:
        return _left_cache[1]
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.get(f"{API}/account.json", params={"api_key": config.SERPAPI_KEY})
            r.raise_for_status()
            acc = r.json()
            left = int(acc.get("total_searches_left") or 0)
            try:
                _renewal = date.fromisoformat(str(acc.get("plan_renewal_date"))[:10])
            except ValueError:
                _renewal = None
    except Exception as e:
        log.warning("serpapi account check failed: %s", e)
        left = 0
    _left_cache = (time.time(), left)
    return left


async def _spent():
    """Каждый реальный запрос уменьшает остаток и пишется в дневной счётчик."""
    global _left_cache
    if _left_cache:
        _left_cache = (_left_cache[0], _left_cache[1] - 1)
    try:
        async with db.pool.connection() as conn:
            await conn.execute(
                """INSERT INTO serpapi_usage (day, used) VALUES (%s, 1)
                   ON CONFLICT (day) DO UPDATE SET used = serpapi_usage.used + 1""", (_today(),))
    except Exception as e:
        log.warning("serpapi usage counter failed: %s", e)


def _today() -> date:
    return datetime.now(ZoneInfo(config.TZ)).date()


async def daily_budget_left() -> int:
    """Сколько запросов на проверку постов можно потратить сегодня:
    (остаток в месяце − резерв) / дней до конца месяца, минус уже потраченное сегодня."""
    today = _today()
    await searches_left()  # заодно узнаём дату обновления квоты
    # квота обновляется не 1-го числа, а в дату продления тарифа; если её не знаем — считаем на 30 дней вперёд
    days_left = (_renewal - today).days if _renewal and _renewal > today else 30
    async with db.pool.connection() as conn:
        row = await (await conn.execute("SELECT used FROM serpapi_usage WHERE day = %s", (today,))).fetchone()
    used_today = row[0] if row else 0
    # остаток на начало дня = текущий остаток + уже потраченное сегодня
    pool_today = await searches_left() + used_today - config.SERPAPI_RESERVE
    return max(0, pool_today // max(days_left, 1) - used_today)


async def _search(params: dict) -> dict | None:
    params = {**params, "api_key": config.SERPAPI_KEY, "currency": "EUR", "hl": "ru", "gl": "rs"}
    try:
        async with httpx.AsyncClient(timeout=60) as c:
            r = await c.get(f"{API}/search.json", params=params)
        await _spent()
        data = r.json()
    except Exception as e:
        log.warning("serpapi %s failed: %s", params.get("engine"), e)
        return None
    if data.get("error"):
        # «нет результатов» по маршруту — обычное дело, это не ошибка
        err = str(data["error"])
        (log.info if "results" in err.lower() else log.warning)("serpapi %s: %s", params.get("engine"), err)
        return None
    return data


def _d(dt) -> str:
    # дата вылета по белградскому времени (в базе timestamptz в UTC — ночной рейс иначе «съедет» на день)
    return dt.astimezone(ZoneInfo(config.TZ)).date().isoformat() if isinstance(dt, datetime) else str(dt)


async def verify(o: dict) -> dict | None:
    """Проверка предложения в Google Flights.
    Возвращает {"price", "level", "range"} или None, если проверить не удалось (тогда публикуем как раньше)."""
    if not enabled() or await searches_left() <= config.SERPAPI_RESERVE:
        return None
    if await daily_budget_left() <= 0:
        log.info("serpapi: daily budget spent, posting without Google check")
        return None
    params = {
        "engine": "google_flights",
        "departure_id": o["origin"],
        # у Google нет «городских» кодов вроде MOW/MIL — берём конкретный аэропорт, если он известен
        "arrival_id": o.get("dest_airport") or o["destination"],
        "outbound_date": _d(o["depart_at"]),
        "type": "2" if o["one_way"] else "1",
    }
    if not o["one_way"] and o.get("return_at"):
        params["return_date"] = _d(o["return_at"])
    data = await _search(params)
    if not data:
        return None
    flights = (data.get("best_flights") or []) + (data.get("other_flights") or [])
    prices = [f["price"] for f in flights if isinstance(f.get("price"), (int, float))]
    ins = data.get("price_insights") or {}
    rng = ins.get("typical_price_range") or []
    return {
        "price": min(prices) if prices else ins.get("lowest_price"),
        "level": ins.get("price_level"),
        "range": rng if len(rng) == 2 else None,
    }


def insight_line(g: dict | None) -> str | None:
    """Строка для поста: «📊 Google Flights: цена низкая (обычно 120–180 €)»,
    а если оценки нет — «📊 Google Flights подтверждает цену: от 69 €»."""
    if not g:
        return None
    if not g.get("level"):
        return f"📊 Google Flights подтверждает цену: от {float(g['price']):.0f} €" if g.get("price") else None
    text = f"📊 Google Flights: цена {LEVELS.get(g['level'], g['level'])}"
    if g.get("range"):
        text += f" (обычно {g['range'][0]:.0f}–{g['range'][1]:.0f} €)"
    return text


async def explore(origin: str, outbound: date, inbound: date) -> list[dict]:
    """Google Travel Explore: куда можно улететь из origin туда-обратно на конкретные даты.
    Один вызов = один запрос из квоты."""
    if not enabled() or await searches_left() <= 0:
        return []
    params = {
        "engine": "google_travel_explore",
        "departure_id": origin,
        "outbound_date": outbound.isoformat(),
        "return_date": inbound.isoformat(),
        "stops": "2",  # не больше одной пересадки
        "travel_mode": "1",  # только перелёты
    }
    data = await _search(params)
    out = []
    for d in (data or {}).get("destinations") or []:
        code = (d.get("destination_airport") or {}).get("code")
        if not code or not d.get("flight_price") or not d.get("start_date"):
            continue
        out.append({
            "name": d.get("name"), "country": d.get("country"), "airport": code,
            "price": float(d["flight_price"]),
            "start": date.fromisoformat(d["start_date"]),
            "end": date.fromisoformat(d["end_date"]) if d.get("end_date") else None,
            "stops": d.get("number_of_stops"), "airline": d.get("airline"),
            "duration": d.get("flight_duration"),
        })
    return out
