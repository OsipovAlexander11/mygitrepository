import re
import logging
from datetime import datetime
from urllib.parse import quote

import httpx

from . import config

log = logging.getLogger(__name__)
API = "https://api.travelpayouts.com"

_cities: dict[str, str] = {}
_city_country: dict[str, str] = {}
_airlines: dict[str, str] = {}
_airport_country: dict[str, str] = {}
_airport_city: dict[str, str] = {}
_countries: dict[str, str] = {}

# свои названия для аэропортов вылета, чтобы не зависеть от справочника
ORIGIN_NAMES = {"BEG": "Белград", "INI": "Ниш", "KVO": "Кралево"}
ORIGIN_GENITIVE = {"BEG": "Белграда", "INI": "Ниша", "KVO": "Кралево"}  # «из Ниша»


def city_from(code: str) -> str:
    return ORIGIN_GENITIVE.get(code) or city_name(code)


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        timeout=30,
        headers={"X-Access-Token": config.TP_TOKEN, "Accept-Encoding": "gzip, deflate"},
    )


async def prices_for_dates(origin: str, month: str, one_way: bool, destination: str | None = None) -> list[dict]:
    """Самые дешёвые найденные билеты из origin за месяц (YYYY-MM): во все направления или в одно."""
    params = {
        "origin": origin,
        "departure_at": month,
        "one_way": str(one_way).lower(),
        "currency": config.CURRENCY,
        "sorting": "price",
        "limit": 1000,
    }
    if destination:
        params["destination"] = destination
    if not one_way:
        params["return_at"] = month  # возврат в том же месяце; длину поездки фильтруем сами
    async with _client() as c:
        r = await c.get(f"{API}/aviasales/v3/prices_for_dates", params=params)
        r.raise_for_status()
        data = r.json()
    if not data.get("success"):
        log.warning("TP error %s %s: %s", origin, month, data.get("error"))
        return []
    return data.get("data") or []


async def load_dictionaries():
    """Русские названия городов и авиакомпаний (кэш в памяти на время жизни процесса)."""
    global _cities, _city_country, _airlines, _airport_country, _airport_city, _countries
    async with _client() as c:
        try:
            r = await c.get(f"{API}/data/ru/cities.json")
            r.raise_for_status()
            cities = r.json()
            _cities = {x["code"]: x.get("name") or x.get("name_translations", {}).get("en") or x["code"]
                       for x in cities}
            _city_country = {x["code"]: x["country_code"] for x in cities if x.get("country_code")}
        except Exception as e:  # справочник не критичен
            log.warning("cities dict failed: %s", e)
        try:
            r = await c.get(f"{API}/data/en/airports.json")
            r.raise_for_status()
            airports = r.json()
            _airport_country = {x["code"]: x["country_code"] for x in airports
                                if x.get("code") and x.get("country_code")}
            _airport_city = {x["code"]: x["city_code"] for x in airports if x.get("code") and x.get("city_code")}
        except Exception as e:
            log.warning("airports dict failed: %s", e)
        try:
            r = await c.get(f"{API}/data/ru/countries.json")
            r.raise_for_status()
            _countries = {x["code"]: x.get("name") or x["code"] for x in r.json() if x.get("code")}
        except Exception as e:
            log.warning("countries dict failed: %s", e)
        try:
            r = await c.get(f"{API}/data/ru/airlines.json")
            r.raise_for_status()
            _airlines = {x["code"]: x.get("name") or x.get("name_translations", {}).get("en") or x["code"]
                         for x in r.json() if x.get("code")}
        except Exception as e:
            log.warning("airlines dict failed: %s", e)
    log.info("dictionaries: %d cities, %d airlines", len(_cities), len(_airlines))


def city_name(code: str) -> str:
    return ORIGIN_NAMES.get(code) or _cities.get(code) or code


def country_of(code: str) -> str | None:
    """Страна по коду города или аэропорта (SAW → TR)."""
    return _city_country.get(code) or _airport_country.get(code)


def country_name(code: str) -> str:
    return _countries.get(code) or code


async def recheck(o: dict) -> dict | None:
    """Свежий запрос в Travelpayouts ровно по маршруту и датам предложения перед публикацией.
    Возвращает самое дешёвое найденное на эти даты (с теми же ограничениями по пересадкам) или None, если пропало."""
    from zoneinfo import ZoneInfo
    tz = ZoneInfo(config.TZ)
    dep = o["depart_at"].astimezone(tz).date()
    params = {
        "origin": o["origin"],
        "destination": o["destination"],
        "departure_at": dep.isoformat(),
        "one_way": str(o["one_way"]).lower(),
        "currency": config.CURRENCY,
        "sorting": "price",
        "limit": 30,
    }
    ret = None
    if not o["one_way"] and o.get("return_at"):
        ret = o["return_at"].astimezone(tz).date()
        params["return_at"] = ret.isoformat()
    try:
        async with _client() as c:
            r = await c.get(f"{API}/aviasales/v3/prices_for_dates", params=params)
            r.raise_for_status()
            data = r.json()
    except Exception as e:
        log.warning("recheck %s-%s failed: %s", o["origin"], o["destination"], e)
        return {"price": float(o["price"]), "link": o["link"], "unchecked": True}  # проверить не смогли — не наказываем
    best = None
    for x in data.get("data") or []:
        try:
            if datetime.fromisoformat(x["departure_at"]).astimezone(tz).date() != dep:
                continue
            if ret and (not x.get("return_at") or datetime.fromisoformat(x["return_at"]).astimezone(tz).date() != ret):
                continue
        except (KeyError, ValueError):
            continue
        if (x.get("transfers") or 0) > config.MAX_TRANSFERS or (x.get("return_transfers") or 0) > config.MAX_TRANSFERS:
            continue
        if best is None or x["price"] < best["price"]:
            best = x
    if not best:
        return None
    return {"price": float(best["price"]), "link": best.get("link") or o["link"],
            "airline": best.get("airline"), "transfers": best.get("transfers", o.get("transfers"))}


def airport_city_name(code: str) -> str:
    """MXP → «Милан», SAW → «Стамбул»."""
    return city_name(_airport_city.get(code, code))


_CHAIN = re.compile(r"\d([A-Z]{9,})")  # в параметре t ссылки: …0675BEGSAWSSH1795… — цепочка аэропортов


def transfer_airports(link: str) -> list[str]:
    """Аэропорты пересадок из ссылки Aviasales (параметр t): BEGSAWSSH → [SAW]. Туда и обратно вместе."""
    out: list[str] = []
    t = link.split("t=", 1)[1].split("&", 1)[0] if "t=" in link else ""
    for chain in _CHAIN.findall(t):
        if len(chain) % 3:
            continue
        codes = [chain[i:i + 3] for i in range(0, len(chain), 3)]
        out += [c for c in codes[1:-1] if c not in out]
    return out


def airline_name(code: str | None) -> str | None:
    if not code:
        return None
    return _airlines.get(code) or code


async def _create_link(url: str, sub_id: str) -> str | None:
    async with _client() as c:
        r = await c.post(f"{API}/links/v1/create", json={
            "trs": int(config.TP_TRS),
            "marker": int(config.TP_MARKER),
            "shorten": True,
            "links": [{"url": url, "sub_id": sub_id}],
        })
        r.raise_for_status()
        item = r.json()["result"]["links"][0]
    if item.get("code") == "success":
        return item["partner_url"]
    log.info("links API failed for %s: %s", url.split("?")[0], item.get("message"))
    return None


def search_url(origin: str, destination: str, depart, ret=None) -> str:
    """Ссылка на результаты поиска Aviasales в формате самого сайта: /search/INI3001IST1
    (откуда, ДДММ вылета, куда, [ДДММ обратно], число взрослых).
    В отличие от ссылок на конкретный тариф (/search/…?t=…&expected_price=…) она не «протухает»,
    когда тариф раскупили, и одинаково открывает маршрут и даты на компьютере и на телефоне."""
    # некоторые коды Travelpayouts мобильная версия Aviasales не понимает (открывает главную) — подменяем
    origin = config.LINK_CODE_OVERRIDES.get(origin, origin)
    destination = config.LINK_CODE_OVERRIDES.get(destination, destination)
    path = f"/search/{origin}{depart:%d%m}{destination}"
    if ret:
        path += f"{ret:%d%m}"
    return config.AVIASALES_HOST.rstrip("/") + path + "1"


def offer_search_url(o: dict) -> str:
    """search_url по предложению из базы (даты — по белградскому времени)."""
    from zoneinfo import ZoneInfo
    tz = ZoneInfo(config.TZ)
    dep = o["depart_at"].astimezone(tz).date()
    ret = o["return_at"].astimezone(tz).date() if not o["one_way"] and o.get("return_at") else None
    return search_url(o["origin"], o["destination"], dep, ret)


async def partner_link(url_or_path: str, sub_id: str) -> str:
    """Партнёрская ссылка (с erid) через Links API. Если API не справился — обычная ссылка с marker."""
    url = url_or_path if url_or_path.startswith("http") else \
        config.AVIASALES_HOST.rstrip("/") + "/" + url_or_path.lstrip("/")
    if config.TP_TRS and config.TP_MARKER:
        try:
            link = await _create_link(url, sub_id)
            if link:
                return link
        except Exception as e:
            log.warning("links API error: %s", e)
        log.warning("partner link without erid (fallback to marker): %s", url.split("?")[0])
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}marker={quote(str(config.TP_MARKER))}" if config.TP_MARKER else url
