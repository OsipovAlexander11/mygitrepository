"""
Визовые требования для владельцев паспортов РФ, РБ и Украины.

База — открытый датасет Passport Index (github.com/ilyankou/passport-index-dataset),
скачивается раз в сутки. Поверх него — ручные правки из visa_overrides.json:
датасет обновляется не мгновенно, а правила меняются (например, безвиз Китая для РФ).
"""
import csv
import io
import json
import logging
from pathlib import Path

import httpx

from . import config

log = logging.getLogger(__name__)

DATASET_URL = ("https://raw.githubusercontent.com/ilyankou/passport-index-dataset/"
               "master/passport-index-tidy-iso2.csv")
CACHE = Path(config.DATA_DIR) / "passport-index.csv"
OVERRIDES = Path(__file__).with_name("visa_overrides.json")

SCHENGEN = set("AT BE BG CH CZ DE DK EE ES FI FR GR HR HU IS IT LI LT LU LV MT NL NO PL PT RO SE SI SK".split())

# (passport, country) -> requirement: "visa free" | "<дни>" | "visa on arrival" | "e-visa" | "eta" |
#                                      "visa required" | "no admission" | "-1" (свой паспорт)
_req: dict[tuple[str, str], str] = {}
_notes: dict[tuple[str, str], str] = {}


def _parse(text: str):
    global _req
    _req = {(r["Passport"], r["Destination"]): r["Requirement"].strip().lower()
            for r in csv.DictReader(io.StringIO(text))}


def _apply_overrides():
    _notes.clear()
    try:
        data = json.loads(OVERRIDES.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("visa overrides not loaded: %s", e)
        return
    for item in data.get("rules", []):
        key = (item["passport"].upper(), item["country"].upper())
        _req[key] = str(item["requirement"]).lower()
        if item.get("note"):
            _notes[key] = item["note"]


async def load():
    text = None
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.get(DATASET_URL)
            r.raise_for_status()
            text = r.text
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_text(text, encoding="utf-8")
    except Exception as e:
        log.warning("visa dataset download failed (%s), using cache", e)
        if CACHE.exists():
            text = CACHE.read_text(encoding="utf-8")
    if text:
        _parse(text)
    _apply_overrides()
    log.info("visa rules: %d pairs", len(_req))


def requirement(passport: str, country: str) -> str | None:
    return _req.get((passport, country))


def is_easy(req: str | None) -> bool:
    """Можно лететь без оформления заранее: безвиз, виза по прилёте или своя страна («-1»)."""
    return bool(req) and (req.isdigit() or req in ("visa free", "visa on arrival", "-1"))


def label(req: str | None, country: str, passport: str) -> str:
    if req is None:
        return "уточняйте"
    if req.isdigit():
        text = f"без визы {req} дн."
    else:
        text = {
            "visa free": "без визы",
            "visa on arrival": "виза по прилёте",
            "e-visa": "e-visa онлайн",
            "eta": "эл. разрешение (ETA)",
            "visa required": "нужна виза" + (" (Шенген)" if country in SCHENGEN else ""),
            "no admission": "въезд закрыт",
        }.get(req, req)
    note = _notes.get((passport, country))
    return f"{text}, {note}" if note else text


def flag(iso2: str) -> str:
    return "".join(chr(0x1F1E6 + ord(c) - ord("A")) for c in iso2.upper())


def summary(country: str | None) -> tuple[str | None, bool]:
    """Строка для поста и признак «без визы для всех» (для хэштега и фильтра)."""
    if not country:
        return None, False
    parts, all_easy, labels = [], True, {}
    for p in config.VISA_PASSPORTS:
        req = requirement(p, country)
        if req == "-1":  # своя страна
            continue
        all_easy &= is_easy(req)
        labels[p] = label(req, country, p)
    if not labels:
        return None, False
    uniq = set(labels.values())
    if len(uniq) == 1:  # у всех одинаково — пишем одной строкой
        flags = "".join(flag(p) for p in labels)
        return f"🛂 {flags}: {uniq.pop()}", all_easy
    return "🛂 " + " · ".join(f"{flag(p)} {t}" for p, t in labels.items()), all_easy


def passes_filter(country: str | None) -> bool:
    mode = config.VISA_FILTER
    if mode == "none" or not country:
        return True
    easy = [is_easy(requirement(p, country)) for p in config.VISA_PASSPORTS
            if requirement(p, country) != "-1"]
    if mode == "any":
        return any(easy)
    if mode == "all":
        return all(easy)
    if mode in {p.lower() for p in config.VISA_PASSPORTS}:  # например VISA_FILTER=ru
        return is_easy(requirement(mode.upper(), country))
    return True
