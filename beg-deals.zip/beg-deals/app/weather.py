"""
Посты «☀️ Где тепло» и «⛷ Снег на курортах» с реальной погодой (Open-Meteo) и ценами из нашей базы.

Open-Meteo бесплатен без ключа для некоммерческого использования; условие — указывать источник
(строка «Погода: Open-Meteo» в посте). Для коммерческого тарифа достаточно задать OPENMETEO_KEY.
Снег — модельная оценка на заданной высоте, на склонах может отличаться (об этом сказано в посте).
"""
import asyncio
import html
import json
import logging
from datetime import datetime
from pathlib import Path
from statistics import mean

import httpx
from psycopg.rows import dict_row

from . import config, db, rates, travelpayouts as tp

log = logging.getLogger(__name__)
FILE = Path(__file__).with_name("places.json")

_places: dict = {}


def load():
    global _places
    try:
        _places = json.loads(FILE.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("places.json not loaded: %s", e)
        _places = {}


def _base(host: str) -> str:
    # коммерческий тариф Open-Meteo — те же адреса с префиксом customer- и параметром apikey
    return f"https://customer-{host}" if config.OPENMETEO_KEY else f"https://{host}"


async def _get(c: httpx.AsyncClient, host: str, path: str, params: dict) -> dict | None:
    if config.OPENMETEO_KEY:
        params = {**params, "apikey": config.OPENMETEO_KEY}
    try:
        r = await c.get(f"{_base(host)}{path}", params=params)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.info("open-meteo %s failed: %s", path, e)
        return None


async def _cheapest(dest: str) -> dict | None:
    """Самый дешёвый билет из главного аэропорта: туда-обратно, если есть, иначе в одну сторону."""
    async with db.pool.connection() as conn, conn.cursor(row_factory=dict_row) as cur:
        await cur.execute(
            """SELECT * FROM offers WHERE origin = %s AND destination = %s
               ORDER BY one_way, price LIMIT 1""", (config.ORIGINS[0], dest))
        return await cur.fetchone()


async def _ticket_line(dest: str | None, sub: str) -> str:
    if not dest:
        return ""
    o = await _cheapest(dest)
    if not o:
        return ""
    link = await tp.partner_link(tp.offer_search_url(o), sub)
    kind = "в одну сторону" if o["one_way"] else "туда-обратно"
    return f' · <a href="{html.escape(link)}">билеты от {rates.price(float(o["price"]))}</a> {kind}'


def _footer(extra: str = "") -> list[str]:
    out = ["", f"<i>Погода: Open-Meteo{extra}. Цены на момент публикации.</i>"]
    if config.AD_DISCLOSURE:
        out.append(f"<i>{html.escape(config.AD_DISCLOSURE)}</i>")
    return out


async def build_warm() -> str | None:
    """Где тепло: средний дневной максимум на 7 дней, температура моря сейчас, билеты из Белграда."""
    rows = []
    async with httpx.AsyncClient(timeout=30) as c:
        for p in _places.get("warm", []):
            w, m = await asyncio.gather(
                _get(c, "api.open-meteo.com", "/v1/forecast", {
                    "latitude": p["lat"], "longitude": p["lon"], "timezone": "auto", "forecast_days": 7,
                    "daily": "temperature_2m_max,precipitation_sum"}),
                _get(c, "marine-api.open-meteo.com", "/v1/marine", {
                    "latitude": p["sea_lat"], "longitude": p["sea_lon"], "current": "sea_surface_temperature"}),
            )
            if not w:
                continue
            tmax = [t for t in w["daily"]["temperature_2m_max"] if t is not None]
            rain = sum(x or 0 for x in w["daily"]["precipitation_sum"])
            sea = (m or {}).get("current", {}).get("sea_surface_temperature")
            if not tmax:
                continue
            rows.append((p, mean(tmax), sea, rain))
    if not rows:
        return None
    rows.sort(key=lambda r: r[1], reverse=True)
    text = ["☀️ <b>Где тепло на этой неделе</b>", "Днём (в среднем за 7 дней) и температура воды сейчас:", ""]
    for p, t, sea, rain in rows:
        line = f'{p["flag"]} <b>{html.escape(p["name"])}</b> — днём {t:+.0f}°'
        if sea is not None:
            line += f", вода {sea:+.0f}°"
        if rain >= 15:
            line += " · ☔ дожди"
        line += await _ticket_line(p.get("dest"), f"warm-{p.get('dest')}")
        text.append(line)
    text += ["", "#где_тепло #зимнее_солнце"] + _footer()
    return "\n".join(text)


async def build_snow() -> str | None:
    """Снег на курортах: глубина снега (модель) на высоте склона, снегопады на неделю, температура, билеты."""
    rows = []
    async with httpx.AsyncClient(timeout=30) as c:
        for p in _places.get("ski", []):
            w = await _get(c, "api.open-meteo.com", "/v1/forecast", {
                "latitude": p["lat"], "longitude": p["lon"], "elevation": p["elevation"], "timezone": "auto",
                "forecast_days": 7, "current": "snow_depth,temperature_2m",
                "daily": "snowfall_sum,temperature_2m_min,temperature_2m_max"})
            if not w:
                continue
            depth = (w.get("current") or {}).get("snow_depth")  # метры
            fresh = sum(x or 0 for x in w["daily"]["snowfall_sum"])  # см за 7 дней
            tmin = min(t for t in w["daily"]["temperature_2m_min"] if t is not None)
            tmax = max(t for t in w["daily"]["temperature_2m_max"] if t is not None)
            rows.append((p, (depth or 0) * 100, fresh, tmin, tmax))
    # курорты без снега и без снегопадов не показываем; если таких все — пост не выходит (сезон ещё не начался)
    rows = [r for r in rows if r[1] >= 5 or r[2] >= 5]
    if not rows:
        return None
    rows.sort(key=lambda r: r[1], reverse=True)
    text = ["⛷ <b>Снег на горнолыжных курортах без визы</b>", ""]
    for p, depth, fresh, tmin, tmax in rows:
        line = f'{p["flag"]} <b>{html.escape(p["name"])}</b> — снега ~{depth:.0f} см'
        if fresh >= 5:
            line += f", ❄️ ожидается ещё ~{fresh:.0f} см"
        line += f", {tmin:+.0f}…{tmax:+.0f}°"
        if p.get("dest"):
            line += f" · {html.escape(p['via'])}" + await _ticket_line(p["dest"], f"snow-{p['dest']}")
        else:
            line += f" · {html.escape(p.get('via') or '')}"
        text.append(line)
    text += ["", "#горнолыжка #безвиз"] + _footer(" (снег — оценка модели на высоте склона, на трассах может отличаться)")
    return "\n".join(text)


async def _publish(builder, kind: str, chat_id: str | None, dry_run: bool) -> bool:
    from .publisher import send  # отложенный импорт: publisher импортирует много всего
    text = await builder()
    if not text:
        log.info("%s: no data", kind)
        return False
    if dry_run:
        print(text)
        return True
    await send(chat_id or config.TG_CHANNEL, text)
    log.info("%s posted", kind)
    return True


def _in_season(months: list[int]) -> bool:
    return datetime.now().month in months


async def publish_warm(chat_id: str | None = None, dry_run: bool = False, force: bool = False) -> bool:
    if not force and not _in_season(config.WARM_MONTHS):
        return False
    return await _publish(build_warm, "warm", chat_id, dry_run)


async def publish_snow(chat_id: str | None = None, dry_run: bool = False, force: bool = False) -> bool:
    if not force and not _in_season(config.SNOW_MONTHS):
        return False
    return await _publish(build_snow, "snow", chat_id, dry_run)
